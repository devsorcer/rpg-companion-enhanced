/**
 * PriorityResolver - Implements Thragg Priority System
 * Resolves conflicts between states based on priority levels
 * Survival > Strong Emotions > Core Personality > Goals > Context > Preferences
 */

import { PRIORITY_LEVELS, URGENCY_THRESHOLDS } from '../core/config.js';

export class PriorityResolver {
    constructor(stateManager) {
        this.stateManager = stateManager;
    }

    /**
     * Get all active priorities
     * Returns array of priority objects sorted by priority level
     */
    getActivePriorities() {
        const priorities = [];
        const state = this.stateManager.getState();
        
        // SURVIVAL NEEDS (Priority 100)
        priorities.push(...this.checkSurvivalNeeds(state));
        
        // STRONG EMOTIONS (Priority 90)
        priorities.push(...this.checkStrongEmotions(state));
        
        // CORE PERSONALITY (Priority 80)
        priorities.push(...this.checkCorePersonality(state));
        
        // GOALS (Priority 70)
        priorities.push(...this.checkGoals(state));
        
        // CONTEXT (Priority 50)
        priorities.push(...this.checkContext(state));
        
        // PREFERENCES (Priority 30)
        priorities.push(...this.checkPreferences(state));
        
        // Sort by priority (highest first)
        return priorities.sort((a, b) => b.priority - a.priority);
    }

    /**
     * Check survival needs (Priority 100)
     */
    checkSurvivalNeeds(state) {
        const needs = [];
        
        // Bladder urgency
        if (state.primaryStates.bladder >= URGENCY_THRESHOLDS.bladder.urgent) {
            needs.push({
                type: 'survival',
                category: 'bladder',
                priority: PRIORITY_LEVELS.SURVIVAL,
                urgency: this.getUrgencyLabel('bladder', state.primaryStates.bladder),
                value: state.primaryStates.bladder,
                message: this.getBladderMessage(state.primaryStates.bladder),
                overrides: 'everything',
                action: 'MUST use bathroom immediately'
            });
        }
        
        // Hunger
        if (state.primaryStates.hunger >= URGENCY_THRESHOLDS.hunger.very_hungry) {
            needs.push({
                type: 'survival',
                category: 'hunger',
                priority: PRIORITY_LEVELS.SURVIVAL,
                urgency: this.getUrgencyLabel('hunger', state.primaryStates.hunger),
                value: state.primaryStates.hunger,
                message: this.getHungerMessage(state.primaryStates.hunger),
                overrides: 'most things',
                action: 'MUST eat soon'
            });
        }
        
        // Energy (exhaustion)
        if (state.primaryStates.energy <= 15) {
            needs.push({
                type: 'survival',
                category: 'energy',
                priority: PRIORITY_LEVELS.SURVIVAL,
                urgency: 'critical',
                value: state.primaryStates.energy,
                message: 'Character is collapsing from exhaustion',
                overrides: 'everything',
                action: 'MUST rest/sleep immediately'
            });
        }
        
        // Pain
        if (state.primaryStates.pain >= 80) {
            needs.push({
                type: 'survival',
                category: 'pain',
                priority: PRIORITY_LEVELS.SURVIVAL,
                urgency: 'severe',
                value: state.primaryStates.pain,
                message: 'Character in severe pain',
                overrides: 'most things',
                action: 'Pain severely limits actions'
            });
        }
        
        // Health critical
        if (state.primaryStates.health <= 20) {
            needs.push({
                type: 'survival',
                category: 'health',
                priority: PRIORITY_LEVELS.SURVIVAL,
                urgency: 'critical',
                value: state.primaryStates.health,
                message: 'Character health is critical',
                overrides: 'everything',
                action: 'MUST seek medical attention'
            });
        }
        
        return needs;
    }

    /**
     * Check strong emotions (Priority 90)
     */
    checkStrongEmotions(state) {
        const emotions = [];
        
        // Stress
        if (state.primaryStates.stress >= 85) {
            emotions.push({
                type: 'strong_emotion',
                category: 'stress',
                priority: PRIORITY_LEVELS.STRONG_EMOTION,
                value: state.primaryStates.stress,
                message: 'Character is extremely stressed - may act irrationally',
                impact: 'Overwhelms rational thought, may cause panic/breakdown'
            });
        }
        
        // Anxiety
        if (state.primaryStates.anxiety >= 80) {
            emotions.push({
                type: 'strong_emotion',
                category: 'anxiety',
                priority: PRIORITY_LEVELS.STRONG_EMOTION,
                value: state.primaryStates.anxiety,
                message: 'Character is severely anxious',
                impact: 'Difficulty concentrating, may freeze or flee'
            });
        }
        
        // Arousal (context-dependent)
        if (state.primaryStates.arousal >= 85 && this.isArousalPriority(state)) {
            emotions.push({
                type: 'strong_emotion',
                category: 'arousal',
                priority: PRIORITY_LEVELS.STRONG_EMOTION,
                value: state.primaryStates.arousal,
                message: 'Character is desperately aroused',
                impact: 'Strong physical need, influences decision-making',
                context: 'Only priority in appropriate contexts'
            });
        }
        
        // Jealousy (intense)
        if (state.primaryStates.jealousy >= 85) {
            emotions.push({
                type: 'strong_emotion',
                category: 'jealousy',
                priority: PRIORITY_LEVELS.STRONG_EMOTION,
                value: state.primaryStates.jealousy,
                message: 'Character consumed by jealousy',
                impact: 'May act possessively or irrationally'
            });
        }
        
        return emotions;
    }

    /**
     * Check core personality traits (Priority 80)
     */
    checkCorePersonality(state) {
        const traits = [];
        
        // High loyalty
        if (state.primaryStates.baseLoyalty >= 90) {
            traits.push({
                type: 'core_personality',
                category: 'loyalty',
                priority: PRIORITY_LEVELS.CORE_PERSONALITY,
                value: state.primaryStates.baseLoyalty,
                message: 'Unwavering loyalty to loved ones',
                impact: 'Will not betray, very difficult to corrupt'
            });
        }
        
        // High morality
        if (state.primaryStates.morality >= 85) {
            traits.push({
                type: 'core_personality',
                category: 'morality',
                priority: PRIORITY_LEVELS.CORE_PERSONALITY,
                value: state.primaryStates.morality,
                message: 'Strong moral compass',
                impact: 'Will resist immoral actions'
            });
        }
        
        // High corruption
        if (state.primaryStates.corruption >= 80) {
            traits.push({
                type: 'core_personality',
                category: 'corruption',
                priority: PRIORITY_LEVELS.CORE_PERSONALITY,
                value: state.primaryStates.corruption,
                message: 'Deeply corrupted morals',
                impact: 'More willing to do questionable things'
            });
        }
        
        return traits;
    }

    /**
     * Check active goals (Priority 70)
     */
    checkGoals(state) {
        const goals = [];
        
        // Short-term goals with high priority
        for (const goal of state.goals.shortTerm) {
            if (goal.priority >= 80) {
                goals.push({
                    type: 'goal',
                    category: 'short_term',
                    priority: PRIORITY_LEVELS.GOALS,
                    value: goal.priority,
                    message: goal.description,
                    progress: goal.progress,
                    deadline: goal.deadline
                });
            }
        }
        
        // Long-term goals with very high priority
        for (const goal of state.goals.longTerm) {
            if (goal.priority >= 90) {
                goals.push({
                    type: 'goal',
                    category: 'long_term',
                    priority: PRIORITY_LEVELS.GOALS,
                    value: goal.priority,
                    message: goal.description,
                    progress: goal.progress
                });
            }
        }
        
        return goals;
    }

    /**
     * Check contextual factors (Priority 50)
     */
    checkContext(state) {
        const context = [];
        
        // Privacy level matters
        if (state.primaryStates.privacyLevel === 'public') {
            context.push({
                type: 'context',
                category: 'privacy',
                priority: PRIORITY_LEVELS.CONTEXT,
                value: state.primaryStates.privacyLevel,
                message: 'In public - social norms apply',
                impact: 'Must maintain propriety, limit certain behaviors'
            });
        }
        
        return context;
    }

    /**
     * Check preferences (Priority 30)
     */
    checkPreferences(state) {
        const prefs = [];
        
        // Cleanliness preference
        if (state.primaryStates.cleanliness < 30) {
            prefs.push({
                type: 'preference',
                category: 'cleanliness',
                priority: PRIORITY_LEVELS.PREFERENCES,
                value: state.primaryStates.cleanliness,
                message: 'Character feels dirty and uncomfortable',
                impact: 'Prefers to bathe when convenient'
            });
        }
        
        return prefs;
    }

    /**
     * Resolve conflict between competing priorities
     */
    resolveConflict(scenario) {
        const priorities = this.getActivePriorities();
        
        if (priorities.length === 0) {
            return {
                winner: null,
                reason: 'No active priorities',
                suggestion: 'Character acts normally based on personality'
            };
        }
        
        const highest = priorities[0];
        
        return {
            winner: highest,
            priorities: priorities,
            reason: `${highest.category} (Priority ${highest.priority}) overrides other considerations`,
            suggestion: highest.action || highest.message,
            fullContext: this.buildConflictContext(priorities)
        };
    }

    /**
     * Build full context for AI
     */
    buildConflictContext(priorities) {
        const lines = ['PRIORITY HIERARCHY:'];
        
        for (const p of priorities) {
            lines.push(`• [${p.priority}] ${p.category}: ${p.message}`);
        }
        
        return lines.join('\n');
    }

    /**
     * Check if arousal should be priority (context-dependent)
     */
    isArousalPriority(state) {
        // Arousal is only high priority in appropriate contexts
        // Not in public, not when survival needs active
        if (state.primaryStates.privacyLevel === 'public') return false;
        if (state.primaryStates.bladder >= 85) return false;
        if (state.primaryStates.hunger >= 85) return false;
        if (state.primaryStates.energy <= 20) return false;
        
        return true;
    }

    /**
     * Get urgency label for state
     */
    getUrgencyLabel(stateName, value) {
        const thresholds = URGENCY_THRESHOLDS[stateName];
        if (!thresholds) return 'normal';
        
        for (const [label, threshold] of Object.entries(thresholds).reverse()) {
            if (value >= threshold) {
                return label;
            }
        }
        
        return 'normal';
    }

    /**
     * Get bladder urgency message
     */
    getBladderMessage(value) {
        if (value >= 100) return 'ACCIDENT IMMINENT - Cannot be delayed';
        if (value >= 95) return 'DESPERATE - About to have accident';
        if (value >= 85) return 'URGENT - Must find bathroom immediately';
        if (value >= 70) return 'Uncomfortable - Needs bathroom soon';
        if (value >= 50) return 'Aware of need - Can wait a bit';
        return 'No urgency';
    }

    /**
     * Get hunger urgency message
     */
    getHungerMessage(value) {
        if (value >= 95) return 'STARVING - Physical weakness, must eat now';
        if (value >= 85) return 'Very hungry - Having trouble concentrating';
        if (value >= 70) return 'Hungry - Should eat soon';
        if (value >= 50) return 'Peckish - Could eat';
        return 'Not hungry';
    }

    /**
     * Get priority alerts (for UI display)
     */
    getPriorityAlerts() {
        const priorities = this.getActivePriorities();
        const alerts = [];
        
        for (const p of priorities) {
            if (p.priority >= PRIORITY_LEVELS.STRONG_EMOTION) {
                alerts.push({
                    level: p.priority >= PRIORITY_LEVELS.SURVIVAL ? 'critical' : 'warning',
                    category: p.category,
                    message: p.message,
                    action: p.action
                });
            }
        }
        
        return alerts;
    }

    /**
     * Check if specific action would be overridden
     */
    wouldBeOverridden(actionType, actionPriority = 50) {
        const activePriorities = this.getActivePriorities();
        
        for (const p of activePriorities) {
            if (p.priority > actionPriority) {
                return {
                    overridden: true,
                    by: p,
                    reason: `${p.category} (${p.priority}) overrides ${actionType} (${actionPriority})`
                };
            }
        }
        
        return { overridden: false };
    }

    /**
     * Get decision framework for AI context
     */
    getDecisionFramework() {
        const priorities = this.getActivePriorities();
        
        if (priorities.length === 0) {
            return 'Character can act freely based on personality, context, and preferences.';
        }
        
        const lines = [
            'DECISION FRAMEWORK (in priority order):',
            ''
        ];
        
        for (const p of priorities) {
            lines.push(`${p.priority}. ${p.category.toUpperCase()}: ${p.message}`);
            if (p.action) {
                lines.push(`   → ${p.action}`);
            }
            if (p.impact) {
                lines.push(`   Impact: ${p.impact}`);
            }
            lines.push('');
        }
        
        lines.push('Lower priority considerations can only influence behavior if they don\'t conflict with higher priorities.');
        
        return lines.join('\n');
    }
}

export default PriorityResolver;
