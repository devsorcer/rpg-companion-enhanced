/**
 * OutfitTracker - Detailed outfit tracking with spatial reasoning
 * Tracks what character is wearing, how revealing it is, how it makes them feel
 */

import { REVEALING_LEVELS, EMPHASIS_LEVELS, FIT_TYPES, VALIDATION } from '../core/config.js';

export class OutfitTracker {
    constructor(stateManager) {
        this.stateManager = stateManager;
    }

    /**
     * Create outfit piece
     */
    createPiece(data) {
        return {
            type: data.type || 'clothing', // top, bottom, dress, underwear, accessory
            name: data.name || 'Unnamed',
            fit: data.fit || 'comfortable',
            material: data.material || '',
            color: data.color || '',
            
            revealing: {
                cleavage: data.revealing?.cleavage || 'none',
                legs: data.revealing?.legs || 'none',
                midriff: data.revealing?.midriff || 'none',
                back: data.revealing?.back || 'none',
                sides: data.revealing?.sides || 'none',
                transparency: data.revealing?.transparency || 'none'
            },
            
            emphasis: {
                breasts: data.emphasis?.breasts || 'none',
                waist: data.emphasis?.waist || 'none',
                hips: data.emphasis?.hips || 'none',
                butt: data.emphasis?.butt || 'none',
                legs: data.emphasis?.legs || 'none'
            },
            
            details: data.details || [],
            visible: data.visible !== false // visible by default
        };
    }

    /**
     * Add piece to outfit
     */
    addPiece(pieceData) {
        const piece = this.createPiece(pieceData);
        return this.stateManager.addOutfitPiece(piece);
    }

    /**
     * Remove piece from outfit
     */
    removePiece(index) {
        return this.stateManager.removeOutfitPiece(index);
    }

    /**
     * Update outfit feelings and narrative
     */
    updateOutfitContext(data) {
        const state = this.stateManager.getState();
        
        state.outfit.overallFeel = data.overallFeel || this.generateOverallFeel(state.outfit.pieces);
        state.outfit.characterFeelings = data.characterFeelings || this.generateCharacterFeelings(state.outfit.pieces);
        state.outfit.spatialNotes = data.spatialNotes || this.generateSpatialNotes(state.outfit.pieces);
        state.outfit.narrativePrompt = data.narrativePrompt || this.generateNarrativePrompt(state.outfit);
    }

    /**
     * Generate overall feel from pieces
     */
    generateOverallFeel(pieces) {
        if (pieces.length === 0) return 'Naked';
        
        const revealingLevels = [];
        const fitTypes = [];
        
        for (const piece of pieces) {
            if (piece.visible) {
                // Check revealing levels
                for (const level of Object.values(piece.revealing)) {
                    if (level !== 'none') {
                        revealingLevels.push(level);
                    }
                }
                
                // Check fit
                fitTypes.push(piece.fit);
            }
        }
        
        const highestRevealing = this.getHighestLevel(revealingLevels, REVEALING_LEVELS);
        const tightestFit = this.getHighestLevel(fitTypes, FIT_TYPES);
        
        let feel = '';
        
        if (highestRevealing === 'none' || highestRevealing === 'minimal') {
            feel = 'Modest and covered';
        } else if (highestRevealing === 'low' || highestRevealing === 'medium') {
            feel = 'Somewhat revealing';
        } else if (highestRevealing === 'high' || highestRevealing === 'very high') {
            feel = 'Very revealing';
        } else {
            feel = 'Extremely revealing';
        }
        
        if (tightestFit === 'tight' || tightestFit === 'very tight' || tightestFit === 'skin-tight') {
            feel += ', form-fitting';
        }
        
        return feel;
    }

    /**
     * Generate character feelings about outfit
     */
    generateCharacterFeelings(pieces) {
        if (pieces.length === 0) return 'Feels exposed and vulnerable';
        
        const revealing = [];
        const tight = [];
        
        for (const piece of pieces) {
            if (piece.visible) {
                // Check what's revealed
                if (piece.revealing.cleavage && piece.revealing.cleavage !== 'none') {
                    revealing.push('cleavage');
                }
                if (piece.revealing.legs && piece.revealing.legs !== 'none') {
                    revealing.push('legs');
                }
                if (piece.revealing.midriff && piece.revealing.midriff !== 'none') {
                    revealing.push('midriff');
                }
                
                // Check tightness
                if (piece.fit === 'tight' || piece.fit === 'very tight' || piece.fit === 'skin-tight') {
                    tight.push(piece.type);
                }
            }
        }
        
        let feeling = '';
        
        if (revealing.length > 0 || tight.length > 0) {
            feeling = 'Feels ';
            
            if (revealing.length > 2) {
                feeling += 'very exposed, ';
            } else if (revealing.length > 0) {
                feeling += 'somewhat exposed, ';
            }
            
            if (tight.length > 0) {
                feeling += 'aware of how tightly everything hugs curves, ';
            }
            
            feeling += 'conscious of appearance and how others might see';
        } else {
            feeling = 'Feels comfortable and modest';
        }
        
        return feeling;
    }

    /**
     * Generate spatial reasoning notes
     */
    generateSpatialNotes(pieces) {
        const notes = [];
        
        for (const piece of pieces) {
            if (!piece.visible) continue;
            
            // Check for spatial implications
            if (piece.type === 'dress' || piece.type === 'skirt') {
                if (piece.details.includes('short') || piece.details.includes('mini')) {
                    notes.push(`${piece.name} is short - sitting or bending would expose underwear`);
                }
            }
            
            if (piece.revealing.cleavage === 'high' || piece.revealing.cleavage === 'very high') {
                notes.push(`${piece.name} has deep neckline - bending forward would show more`);
            }
            
            if (piece.fit === 'very tight' || piece.fit === 'skin-tight') {
                notes.push(`${piece.name} is so tight that every movement emphasizes curves`);
            }
            
            if (piece.revealing.back === 'high' || piece.revealing.back === 'very high') {
                notes.push(`${piece.name} exposes back - no bra straps visible means no bra or special bra`);
            }
            
            if (piece.type === 'underwear' && piece.visible) {
                notes.push(`${piece.name} is visible through/under other clothing`);
            }
        }
        
        return notes.join('. ');
    }

    /**
     * Generate narrative prompt for AI
     */
    generateNarrativePrompt(outfit) {
        if (outfit.pieces.length === 0) {
            return 'Character is completely naked.';
        }
        
        const lines = [];
        
        // Start with overall description
        lines.push(`Character is wearing:`);
        
        // Describe each visible piece
        for (const piece of outfit.pieces) {
            if (!piece.visible) continue;
            
            let desc = `• ${piece.name}`;
            
            if (piece.color) {
                desc += ` (${piece.color})`;
            }
            
            if (piece.fit !== 'comfortable') {
                desc += ` - ${piece.fit} fit`;
            }
            
            if (piece.material) {
                desc += `, ${piece.material}`;
            }
            
            // Add revealing details
            const revealing = [];
            for (const [area, level] of Object.entries(piece.revealing)) {
                if (level !== 'none') {
                    revealing.push(`${area}: ${level}`);
                }
            }
            
            if (revealing.length > 0) {
                desc += `. Reveals: ${revealing.join(', ')}`;
            }
            
            // Add emphasis details
            const emphasis = [];
            for (const [area, level] of Object.entries(piece.emphasis)) {
                if (level !== 'none' && level !== 'slight') {
                    emphasis.push(`${area}`);
                }
            }
            
            if (emphasis.length > 0) {
                desc += `. Emphasizes: ${emphasis.join(', ')}`;
            }
            
            // Add custom details
            if (piece.details.length > 0) {
                desc += `. Details: ${piece.details.join(', ')}`;
            }
            
            lines.push(desc);
        }
        
        lines.push('');
        lines.push(`Overall: ${outfit.overallFeel}`);
        lines.push(`Character feels: ${outfit.characterFeelings}`);
        
        if (outfit.spatialNotes) {
            lines.push('');
            lines.push(`Spatial considerations: ${outfit.spatialNotes}`);
        }
        
        return lines.join('\n');
    }

    /**
     * Get highest level from array
     */
    getHighestLevel(items, levels) {
        let highest = levels[0];
        
        for (const item of items) {
            const index = levels.indexOf(item);
            const currentIndex = levels.indexOf(highest);
            
            if (index > currentIndex) {
                highest = item;
            }
        }
        
        return highest;
    }

    /**
     * Quick outfit presets
     */
    createPresetOutfit(presetName, characterStats = {}) {
        const presets = {
            'casual_modest': [
                {
                    type: 'top',
                    name: 'Simple t-shirt',
                    fit: 'comfortable',
                    material: 'cotton',
                    color: 'white',
                    revealing: { cleavage: 'none', midriff: 'none' },
                    emphasis: { breasts: 'none' }
                },
                {
                    type: 'bottom',
                    name: 'Jeans',
                    fit: 'comfortable',
                    material: 'denim',
                    color: 'blue',
                    revealing: { legs: 'none' },
                    emphasis: { hips: 'slight', butt: 'slight' }
                }
            ],
            
            'sexy_revealing': [
                {
                    type: 'dress',
                    name: 'Tight mini dress',
                    fit: 'very tight',
                    material: 'stretch fabric',
                    color: 'red',
                    revealing: { cleavage: 'high', legs: 'very high' },
                    emphasis: { breasts: 'very high', waist: 'high', hips: 'high' },
                    details: ['short', 'low neckline', 'body-hugging']
                },
                {
                    type: 'underwear',
                    name: 'Lace panties',
                    visible: false
                }
            ],
            
            'cozy_home': [
                {
                    type: 'top',
                    name: 'Oversized sweater',
                    fit: 'very loose',
                    material: 'knit',
                    color: 'gray',
                    revealing: { cleavage: 'low' },
                    emphasis: { breasts: 'none' },
                    details: ['comfortable', 'warm', 'slouchy neckline']
                },
                {
                    type: 'bottom',
                    name: 'Pajama shorts',
                    fit: 'loose',
                    material: 'soft cotton',
                    revealing: { legs: 'high' }
                }
            ]
        };
        
        return presets[presetName] || [];
    }

    /**
     * Load outfit from preset
     */
    loadPreset(presetName) {
        const pieces = this.createPresetOutfit(presetName);
        
        // Clear current outfit
        const state = this.stateManager.getState();
        state.outfit.pieces = [];
        
        // Add preset pieces
        for (const piece of pieces) {
            this.addPiece(piece);
        }
        
        // Update context
        this.updateOutfitContext({});
        
        return true;
    }

    /**
     * Get outfit summary for display
     */
    getSummary() {
        const state = this.stateManager.getState();
        
        return {
            pieces: state.outfit.pieces,
            overallFeel: state.outfit.overallFeel,
            characterFeelings: state.outfit.characterFeelings,
            spatialNotes: state.outfit.spatialNotes,
            pieceCount: state.outfit.pieces.filter(p => p.visible).length
        };
    }

    /**
     * Validate revealing levels
     */
    validateRevealingLevel(level) {
        return REVEALING_LEVELS.includes(level);
    }

    /**
     * Validate emphasis level
     */
    validateEmphasisLevel(level) {
        return EMPHASIS_LEVELS.includes(level);
    }

    /**
     * Validate fit type
     */
    validateFitType(fit) {
        return FIT_TYPES.includes(fit);
    }
}

export default OutfitTracker;
