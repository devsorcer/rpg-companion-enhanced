/**
 * StateManager - Core state management for Advanced RPG Companion
 * Handles all 60-70+ character states, validation, and updates
 */

import { PRIMARY_STATES, VALIDATION } from '../core/config.js';

export class StateManager {
    constructor() {
        this.state = this.createDefaultState();
        this.lastUpdate = Date.now();
    }

    /**
     * Create default state object with all fields
     */
    createDefaultState() {
        return {
            // Metadata
            characterId: null,
            characterName: null,
            lastUpdated: Date.now(),
            swipeId: null,
            
            // Primary States (38)
            primaryStates: this.createPrimaryStates(),
            
            // Secondary States
            secondaryStates: {
                activeMoods: [],
                conditions: [],
                temporaryBoosts: {},
                temporaryPenalties: {}
            },
            
            // Biology Tracking
            biology: {
                cycleDay: 1,
                cyclePhase: 'follicular',
                pregnant: false,
                pregnancyWeek: 0,
                lastMeal: null,
                lastBathroom: null,
                lastSleep: null,
                lastBathed: null
            },
            
            // Outfit System
            outfit: {
                pieces: [],
                overallFeel: '',
                characterFeelings: '',
                spatialNotes: '',
                narrativePrompt: ''
            },
            
            // Memory System
            memories: {
                recentEvents: [],
                importantMemories: [],
                secrets: [],
                traumas: []
            },
            
            // Thoughts System
            thoughts: {
                currentThoughts: '',
                thoughtsAboutNPCs: {},
                activeConcerns: []
            },
            
            // Beliefs System
            beliefs: [],
            
            // Desires System
            desires: [],
            
            // Goals System
            goals: {
                shortTerm: [],
                longTerm: [],
                secret: []
            },
            
            // Relationships (per NPC)
            relationships: {}
        };
    }

    /**
     * Create primary states with default values
     */
    createPrimaryStates() {
        const states = {};
        
        for (const category of Object.values(PRIMARY_STATES)) {
            for (const [key, config] of Object.entries(category)) {
                states[key] = config.default;
            }
        }
        
        return states;
    }

    /**
     * Get current state
     */
    getState() {
        return this.state;
    }

    /**
     * Set entire state
     */
    setState(newState) {
        this.state = newState;
        this.lastUpdate = Date.now();
    }

    /**
     * Update specific primary state with validation
     */
    updatePrimaryState(stateName, value) {
        // Find stat config
        let config = null;
        for (const category of Object.values(PRIMARY_STATES)) {
            if (category[stateName]) {
                config = category[stateName];
                break;
            }
        }
        
        if (!config) {
            console.warn(`[StateManager] Unknown state: ${stateName}`);
            return false;
        }
        
        // Validate based on type
        if (config.type === 'text' || config.type === 'enum') {
            this.state.primaryStates[stateName] = value;
        } else if (config.type === 'boolean') {
            this.state.primaryStates[stateName] = Boolean(value);
        } else {
            // Numeric - clamp to min/max
            const numValue = Number(value);
            if (isNaN(numValue)) {
                console.warn(`[StateManager] Invalid numeric value for ${stateName}: ${value}`);
                return false;
            }
            
            this.state.primaryStates[stateName] = Math.max(
                config.min,
                Math.min(config.max, numValue)
            );
        }
        
        this.lastUpdate = Date.now();
        return true;
    }

    /**
     * Update multiple primary states at once
     */
    updatePrimaryStates(updates) {
        const results = {};
        
        for (const [key, value] of Object.entries(updates)) {
            results[key] = this.updatePrimaryState(key, value);
        }
        
        return results;
    }

    /**
     * Get primary state value
     */
    getPrimaryState(stateName) {
        return this.state.primaryStates[stateName];
    }

    /**
     * Add memory event
     */
    addMemoryEvent(event) {
        const memory = {
            timestamp: Date.now(),
            event: event.event || event,
            significance: event.significance || 'low',
            emotionalImpact: event.emotionalImpact || {}
        };
        
        this.state.memories.recentEvents.unshift(memory);
        
        // Keep only last N events
        if (this.state.memories.recentEvents.length > VALIDATION.MAX_MEMORY_EVENTS) {
            this.state.memories.recentEvents = this.state.memories.recentEvents.slice(0, VALIDATION.MAX_MEMORY_EVENTS);
        }
    }

    /**
     * Add important memory
     */
    addImportantMemory(memory) {
        this.state.memories.importantMemories.push({
            date: memory.date || new Date().toISOString(),
            event: memory.event,
            significance: memory.significance || 'high',
            emotionalImpact: memory.emotionalImpact || {}
        });
        
        // Keep only last N important memories
        if (this.state.memories.importantMemories.length > VALIDATION.MAX_IMPORTANT_MEMORIES) {
            this.state.memories.importantMemories.shift();
        }
    }

    /**
     * Add secret
     */
    addSecret(secret) {
        if (!this.state.memories.secrets.includes(secret)) {
            this.state.memories.secrets.push(secret);
            
            // Keep only last N secrets
            if (this.state.memories.secrets.length > VALIDATION.MAX_SECRETS) {
                this.state.memories.secrets.shift();
            }
        }
    }

    /**
     * Update current thoughts
     */
    updateThoughts(thoughts) {
        if (typeof thoughts === 'string') {
            this.state.thoughts.currentThoughts = thoughts.slice(0, VALIDATION.MAX_THOUGHT_LENGTH);
        }
    }

    /**
     * Update thoughts about specific NPC
     */
    updateNPCThoughts(npcName, thoughts) {
        this.state.thoughts.thoughtsAboutNPCs[npcName] = thoughts.slice(0, VALIDATION.MAX_THOUGHT_LENGTH);
    }

    /**
     * Add or update goal
     */
    addGoal(type, goal) {
        if (!['shortTerm', 'longTerm', 'secret'].includes(type)) {
            console.warn(`[StateManager] Invalid goal type: ${type}`);
            return false;
        }
        
        const goalObj = {
            description: goal.description,
            priority: goal.priority || 50,
            progress: goal.progress || 0,
            deadline: goal.deadline || null
        };
        
        this.state.goals[type].push(goalObj);
        
        // Keep only max goals
        if (this.state.goals[type].length > VALIDATION.MAX_GOALS) {
            this.state.goals[type].shift();
        }
        
        return true;
    }

    /**
     * Add or update relationship
     */
    addRelationship(npcName, relationship) {
        this.state.relationships[npcName] = {
            relationshipType: relationship.relationshipType || 'Acquaintance',
            feelings: relationship.feelings || '',
            thoughts: relationship.thoughts || '',
            recentMemories: relationship.recentMemories || [],
            secrets: relationship.secrets || [],
            universalStats: relationship.universalStats || {
                respect: 50,
                fear: 0,
                obedience: 30,
                dominance: 50,
                trust: 50,
                closeness: 40
            },
            romanticStats: relationship.romanticStats || null,
            lastInteraction: relationship.lastInteraction || new Date().toISOString(),
            growthRates: relationship.growthRates || {}
        };
    }

    /**
     * Update relationship stat
     */
    updateRelationshipStat(npcName, statName, value) {
        if (!this.state.relationships[npcName]) {
            console.warn(`[StateManager] Unknown NPC: ${npcName}`);
            return false;
        }
        
        const rel = this.state.relationships[npcName];
        
        // Check if universal or romantic stat
        if (rel.universalStats && rel.universalStats.hasOwnProperty(statName)) {
            rel.universalStats[statName] = Math.max(0, Math.min(100, Number(value)));
            return true;
        }
        
        if (rel.romanticStats && rel.romanticStats.hasOwnProperty(statName)) {
            rel.romanticStats[statName] = Math.max(0, Math.min(100, Number(value)));
            return true;
        }
        
        console.warn(`[StateManager] Unknown relationship stat: ${statName}`);
        return false;
    }

    /**
     * Update outfit
     */
    updateOutfit(outfit) {
        this.state.outfit = {
            pieces: outfit.pieces || [],
            overallFeel: outfit.overallFeel || '',
            characterFeelings: outfit.characterFeelings || '',
            spatialNotes: outfit.spatialNotes || '',
            narrativePrompt: outfit.narrativePrompt || ''
        };
    }

    /**
     * Add outfit piece
     */
    addOutfitPiece(piece) {
        if (this.state.outfit.pieces.length >= VALIDATION.MAX_OUTFIT_PIECES) {
            console.warn('[StateManager] Maximum outfit pieces reached');
            return false;
        }
        
        this.state.outfit.pieces.push({
            type: piece.type || 'clothing',
            name: piece.name || 'Unnamed',
            fit: piece.fit || 'comfortable',
            material: piece.material || '',
            color: piece.color || '',
            revealing: piece.revealing || {},
            emphasis: piece.emphasis || {},
            details: piece.details || []
        });
        
        return true;
    }

    /**
     * Remove outfit piece
     */
    removeOutfitPiece(index) {
        if (index >= 0 && index < this.state.outfit.pieces.length) {
            this.state.outfit.pieces.splice(index, 1);
            return true;
        }
        return false;
    }

    /**
     * Update biology data
     */
    updateBiology(field, value) {
        if (this.state.biology.hasOwnProperty(field)) {
            this.state.biology[field] = value;
            return true;
        }
        return false;
    }

    /**
     * Add belief
     */
    addBelief(belief) {
        this.state.beliefs.push({
            name: belief.name,
            strength: belief.strength || 50,
            category: belief.category || 'personal'
        });
    }

    /**
     * Add desire
     */
    addDesire(desire) {
        this.state.desires.push({
            name: desire.name,
            intensity: desire.intensity || 50,
            satisfaction: desire.satisfaction || 0,
            priority: desire.priority || 50
        });
    }

    /**
     * Get state summary for display
     */
    getSummary() {
        return {
            physical: this.getPhysicalSummary(),
            emotional: this.getEmotionalSummary(),
            moral: this.getMoralSummary(),
            context: this.getContextSummary(),
            priorities: this.getPriorities()
        };
    }

    /**
     * Get physical states summary
     */
    getPhysicalSummary() {
        const physical = {};
        for (const [key, config] of Object.entries(PRIMARY_STATES.PHYSICAL)) {
            physical[key] = {
                value: this.state.primaryStates[key],
                label: config.label,
                urgency: this.getUrgencyLevel(key, this.state.primaryStates[key])
            };
        }
        return physical;
    }

    /**
     * Get emotional states summary
     */
    getEmotionalSummary() {
        const emotional = {};
        for (const [key, config] of Object.entries(PRIMARY_STATES.EMOTIONAL)) {
            emotional[key] = {
                value: this.state.primaryStates[key],
                label: config.label
            };
        }
        return emotional;
    }

    /**
     * Get moral states summary
     */
    getMoralSummary() {
        const moral = {};
        for (const [key, config] of Object.entries(PRIMARY_STATES.MORAL)) {
            moral[key] = {
                value: this.state.primaryStates[key],
                label: config.label
            };
        }
        return moral;
    }

    /**
     * Get contextual info
     */
    getContextSummary() {
        return {
            location: this.state.primaryStates.currentLocation,
            privacy: this.state.primaryStates.privacyLevel,
            activity: this.state.primaryStates.currentActivity,
            mood: this.state.primaryStates.currentMood
        };
    }

    /**
     * Get urgency level for a state
     */
    getUrgencyLevel(stateName, value) {
        // Implement urgency thresholds
        if (stateName === 'bladder') {
            if (value >= 95) return 'desperate';
            if (value >= 85) return 'urgent';
            if (value >= 70) return 'uncomfortable';
            if (value >= 50) return 'aware';
        }
        
        if (stateName === 'hunger') {
            if (value >= 95) return 'starving';
            if (value >= 85) return 'very_hungry';
            if (value >= 70) return 'hungry';
            if (value >= 50) return 'peckish';
        }
        
        return 'normal';
    }

    /**
     * Get current priorities
     */
    getPriorities() {
        const priorities = [];
        
        // Check survival needs
        if (this.state.primaryStates.bladder >= 85) {
            priorities.push({ type: 'survival', stat: 'bladder', value: this.state.primaryStates.bladder, priority: 100 });
        }
        if (this.state.primaryStates.hunger >= 85) {
            priorities.push({ type: 'survival', stat: 'hunger', value: this.state.primaryStates.hunger, priority: 100 });
        }
        if (this.state.primaryStates.energy <= 15) {
            priorities.push({ type: 'survival', stat: 'energy', value: this.state.primaryStates.energy, priority: 100 });
        }
        
        // Check strong emotions
        if (this.state.primaryStates.stress >= 85) {
            priorities.push({ type: 'emotion', stat: 'stress', value: this.state.primaryStates.stress, priority: 90 });
        }
        if (this.state.primaryStates.anxiety >= 80) {
            priorities.push({ type: 'emotion', stat: 'anxiety', value: this.state.primaryStates.anxiety, priority: 90 });
        }
        
        // Sort by priority
        return priorities.sort((a, b) => b.priority - a.priority);
    }

    /**
     * Export state for saving
     */
    export() {
        return JSON.stringify(this.state);
    }

    /**
     * Import state from saved data
     */
    import(data) {
        try {
            const parsed = typeof data === 'string' ? JSON.parse(data) : data;
            this.state = { ...this.createDefaultState(), ...parsed };
            this.lastUpdate = Date.now();
            return true;
        } catch (error) {
            console.error('[StateManager] Failed to import state:', error);
            return false;
        }
    }

    /**
     * Reset to default state
     */
    reset() {
        this.state = this.createDefaultState();
        this.lastUpdate = Date.now();
    }
}

export default StateManager;
