/**
 * SlowBurnValidator - Enforces realistic stat changes
 * Prevents unrealistic jumps, validates requirements, applies slow-burn rules
 */

import { DEFAULT_SLOW_BURN, GROWTH_RATES, DECAY_RATES } from '../core/config.js';

export class SlowBurnValidator {
    constructor(settings = null) {
        this.settings = settings || DEFAULT_SLOW_BURN;
    }

    /**
     * Update settings
     */
    updateSettings(newSettings) {
        this.settings = { ...this.settings, ...newSettings };
    }

    /**
     * Validate a state change
     * @param {string} statName - Name of the stat
     * @param {number} currentValue - Current value
     * @param {number} newValue - Proposed new value
     * @param {object} context - Additional context (other states, events, etc.)
     * @returns {number} Validated value
     */
    validateChange(statName, currentValue, newValue, context = {}) {
        // Get config for this stat
        const config = this.settings.perStatSettings[statName];
        
        if (!config) {
            // No config - allow change but clamp to 0-100
            return Math.max(0, Math.min(100, newValue));
        }
        
        // Calculate change
        const change = newValue - currentValue;
        const absChange = Math.abs(change);
        
        // 1. Check if automatic (time-based)
        if (config.growthRate === 'automatic') {
            // Time-based stats handled separately
            return newValue;
        }
        
        // 2. Check maximum change per event
        if (absChange > config.maxChangePerEvent) {
            console.log(`[SlowBurn] ${statName} change capped: ${absChange} → ${config.maxChangePerEvent}`);
            
            // Check if spike is allowed
            if (change > 0 && !config.canSpikeUp) {
                return currentValue + config.maxChangePerEvent;
            }
            if (change < 0 && !config.canSpikeDown) {
                return currentValue - config.maxChangePerEvent;
            }
            
            // Spike allowed but apply multiplier
            const maxSpike = config.maxChangePerEvent * (config.spikeMultiplier || 1);
            if (absChange > maxSpike) {
                return currentValue + (change > 0 ? maxSpike : -maxSpike);
            }
        }
        
        // 3. Check requirements
        if (config.requirements) {
            if (!this.checkRequirements(statName, config.requirements, context)) {
                console.log(`[SlowBurn] ${statName} requirements not met`);
                return currentValue; // No change
            }
        }
        
        // 4. Check logical progression
        if (this.settings.globalRules.requireLogicalProgression) {
            if (!this.isLogicalProgression(statName, currentValue, newValue, context)) {
                console.log(`[SlowBurn] ${statName} change not logical`);
                return currentValue; // No change
            }
        }
        
        // 5. Check relationship momentum
        if (this.settings.globalRules.relationshipMomentum && context.isRelationshipStat) {
            const momentum = this.calculateMomentum(currentValue);
            const maxChangeWithMomentum = config.maxChangePerEvent / momentum;
            
            if (absChange > maxChangeWithMomentum) {
                console.log(`[SlowBurn] ${statName} momentum applied: ${absChange} → ${maxChangeWithMomentum}`);
                return currentValue + (change > 0 ? maxChangeWithMomentum : -maxChangeWithMomentum);
            }
        }
        
        // All checks passed
        return Math.max(0, Math.min(100, newValue));
    }

    /**
     * Check if requirements are met for stat change
     */
    checkRequirements(statName, requirements, context) {
        // Check minimum trust requirement
        if (requirements.minTrust && context.trust < requirements.minTrust) {
            return false;
        }
        
        // Check minimum closeness requirement
        if (requirements.minCloseness && context.closeness < requirements.minCloseness) {
            return false;
        }
        
        // Check repeated actions requirement (for corruption)
        if (requirements.repeatedActions && !context.repeatedAction) {
            return false;
        }
        
        return true;
    }

    /**
     * Check if change is logically consistent
     */
    isLogicalProgression(statName, oldValue, newValue, context) {
        // Love shouldn't increase if trust is decreasing
        if (statName === 'love' && context.changes && context.changes.trust < 0) {
            if (newValue > oldValue) {
                return false;
            }
        }
        
        // Trust shouldn't increase if being betrayed
        if (statName === 'trust' && context.betrayed) {
            if (newValue > oldValue) {
                return false;
            }
        }
        
        // Respect shouldn't increase if being humiliated
        if (statName === 'respect' && context.humiliated) {
            if (newValue > oldValue) {
                return false;
            }
        }
        
        // Fear should increase if threatened
        if (statName === 'fear' && context.threatened) {
            if (newValue < oldValue) {
                return false; // Should be increasing
            }
        }
        
        return true;
    }

    /**
     * Calculate momentum factor (established relationships harder to change)
     */
    calculateMomentum(currentValue) {
        // Values near extremes (0 or 100) are harder to change
        if (currentValue >= 80 || currentValue <= 20) {
            return 2; // 2x harder to change
        }
        if (currentValue >= 60 || currentValue <= 40) {
            return 1.5; // 1.5x harder
        }
        return 1; // Normal
    }

    /**
     * Validate multiple changes at once
     */
    validateMultipleChanges(changes, context) {
        const validated = {};
        
        for (const [statName, newValue] of Object.entries(changes)) {
            const currentValue = context.currentValues[statName] || 50;
            validated[statName] = this.validateChange(statName, currentValue, newValue, context);
        }
        
        return validated;
    }

    /**
     * Calculate growth rate multiplier
     */
    getGrowthRateMultiplier(rateString) {
        const rates = {
            'very slow': 0.5,
            'slow': 0.75,
            'medium': 1.0,
            'fast': 1.5,
            'very fast': 2.0
        };
        
        return rates[rateString] || 1.0;
    }

    /**
     * Calculate decay rate multiplier
     */
    getDecayRateMultiplier(rateString) {
        const rates = {
            'never': 0,
            'very slow': 0.5,
            'slow': 1.0,
            'medium': 1.5,
            'fast': 2.0
        };
        
        return rates[rateString] || 0;
    }

    /**
     * Apply time-based decay
     */
    applyTimeDecay(statName, currentValue, timePassedHours) {
        const config = this.settings.perStatSettings[statName];
        
        if (!config) return currentValue;
        
        // Check if has baseline reversion (e.g., arousal)
        if (config.baselineReversion) {
            const baseline = config.baseline || 10;
            const rate = config.baselineRate || 5;
            
            if (currentValue > baseline) {
                return Math.max(baseline, currentValue - (rate * timePassedHours));
            }
            if (currentValue < baseline) {
                return Math.min(baseline, currentValue + (rate * timePassedHours));
            }
            
            return currentValue;
        }
        
        // Regular decay
        const decayMultiplier = this.getDecayRateMultiplier(config.decayRate);
        if (decayMultiplier === 0) return currentValue; // Never decays
        
        // Assume some base decay rate (e.g., 2 points per hour)
        const baseDecayRate = 2;
        const decay = baseDecayRate * decayMultiplier * timePassedHours;
        
        return Math.max(0, currentValue - decay);
    }

    /**
     * Get warning message if change would be capped
     */
    getWarningMessage(statName, currentValue, proposedValue) {
        const config = this.settings.perStatSettings[statName];
        if (!config) return null;
        
        const change = Math.abs(proposedValue - currentValue);
        
        if (change > config.maxChangePerEvent) {
            return `${statName} change too large: ${change} exceeds max ${config.maxChangePerEvent}`;
        }
        
        return null;
    }

    /**
     * Suggest realistic value
     */
    suggestRealisticValue(statName, currentValue, desiredValue, context = {}) {
        const validated = this.validateChange(statName, currentValue, desiredValue, context);
        
        if (validated !== desiredValue) {
            return {
                suggested: validated,
                original: desiredValue,
                reason: this.getWarningMessage(statName, currentValue, desiredValue)
            };
        }
        
        return {
            suggested: desiredValue,
            original: desiredValue,
            reason: null
        };
    }

    /**
     * Check if change is unrealistic
     */
    isUnrealisticJump(statName, currentValue, newValue) {
        if (this.settings.globalRules.preventUnrealisticJumps) {
            const change = Math.abs(newValue - currentValue);
            
            // Jump of more than 50 in one event is always unrealistic
            if (change > 50) return true;
            
            // Check against max change per event
            const config = this.settings.perStatSettings[statName];
            if (config && change > config.maxChangePerEvent * 2) {
                return true;
            }
        }
        
        return false;
    }

    /**
     * Get configuration for a stat
     */
    getStatConfig(statName) {
        return this.settings.perStatSettings[statName] || null;
    }

    /**
     * Update stat configuration
     */
    updateStatConfig(statName, config) {
        this.settings.perStatSettings[statName] = {
            ...this.settings.perStatSettings[statName],
            ...config
        };
    }

    /**
     * Reset to defaults
     */
    reset() {
        this.settings = { ...DEFAULT_SLOW_BURN };
    }

    /**
     * Export settings
     */
    export() {
        return JSON.stringify(this.settings);
    }

    /**
     * Import settings
     */
    import(data) {
        try {
            const parsed = typeof data === 'string' ? JSON.parse(data) : data;
            this.settings = { ...DEFAULT_SLOW_BURN, ...parsed };
            return true;
        } catch (error) {
            console.error('[SlowBurnValidator] Failed to import settings:', error);
            return false;
        }
    }
}

export default SlowBurnValidator;
