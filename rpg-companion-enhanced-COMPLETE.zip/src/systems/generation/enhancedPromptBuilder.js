/**
 * PromptBuilder - Builds rich context prompts for AI
 * Converts states into human-readable context
 * Implements context-driven approach (not parser-based)
 */

import { URGENCY_THRESHOLDS, getCyclePhase } from '../core/config.js';

export class PromptBuilder {
    constructor(stateManager, priorityResolver, outfitTracker) {
        this.stateManager = stateManager;
        this.priorityResolver = priorityResolver;
        this.outfitTracker = outfitTracker;
    }

    /**
     * Build complete context for AI generation
     */
    buildFullContext() {
        const state = this.stateManager.getState();
        const priorities = this.priorityResolver.getActivePriorities();
        
        const sections = [
            this.buildHeader(),
            this.buildPhysicalStates(),
            this.buildEmotionalStates(),
            this.buildMoralFramework(),
            this.buildCurrentContext(),
            this.buildOutfitDescription(),
            this.buildRelationships(),
            this.buildThoughtsAndMemories(),
            this.buildGoalsAndDesires(),
            this.buildPrioritySystem(priorities),
            this.buildDecisionFramework(priorities)
        ];
        
        return sections.filter(s => s).join('\n\n');
    }

    /**
     * Build header
     */
    buildHeader() {
        const state = this.stateManager.getState();
        
        return `# CHARACTER STATE CONTEXT\n\nCharacter: ${state.characterName || 'Unknown'}\nLast Updated: ${new Date(state.lastUpdated).toLocaleString()}`;
    }

    /**
     * Build physical states section
     */
    buildPhysicalStates() {
        const state = this.stateManager.getState();
        const lines = ['## PHYSICAL STATES'];
        
        // Bladder
        const bladderUrgency = this.getUrgencyDescription('bladder', state.primaryStates.bladder);
        lines.push(`• Bladder: ${state.primaryStates.bladder}/100${bladderUrgency ? ` - ${bladderUrgency}` : ''}`);
        
        // Arousal
        const arousalDesc = this.getArousalDescription(state.primaryStates.arousal);
        lines.push(`• Arousal: ${state.primaryStates.arousal}/100${arousalDesc ? ` - ${arousalDesc}` : ''}`);
        
        // Hunger
        const hungerDesc = this.getUrgencyDescription('hunger', state.primaryStates.hunger);
        lines.push(`• Hunger: ${state.primaryStates.hunger}/100${hungerDesc ? ` - ${hungerDesc}` : ''}`);
        
        // Energy
        const energyDesc = this.getEnergyDescription(state.primaryStates.energy);
        lines.push(`• Energy: ${state.primaryStates.energy}/100${energyDesc ? ` - ${energyDesc}` : ''}`);
        
        // Only show others if notable
        if (state.primaryStates.pain > 20) {
            lines.push(`• Pain: ${state.primaryStates.pain}/100 - Experiencing discomfort`);
        }
        
        if (state.primaryStates.cleanliness < 50) {
            lines.push(`• Cleanliness: ${state.primaryStates.cleanliness}/100 - Feels unclean`);
        }
        
        if (state.primaryStates.intoxication > 0) {
            lines.push(`• Intoxication: ${state.primaryStates.intoxication}/100 - Under influence`);
        }
        
        // Cycle info
        const cycle = getCyclePhase(state.primaryStates.cycleDay);
        lines.push(`• Menstrual Cycle: Day ${state.primaryStates.cycleDay}/28 (${cycle.label} ${cycle.emoji})`);
        
        return lines.join('\n');
    }

    /**
     * Build emotional states section
     */
    buildEmotionalStates() {
        const state = this.stateManager.getState();
        const lines = ['## EMOTIONAL STATES'];
        
        lines.push(`• Happiness: ${state.primaryStates.happiness}/100`);
        lines.push(`• Current Mood: ${state.primaryStates.currentMood}`);
        
        // Only show if notable
        if (state.primaryStates.stress > 30) {
            lines.push(`• Stress: ${state.primaryStates.stress}/100${state.primaryStates.stress >= 85 ? ' ⚠️ CRITICAL' : ''}`);
        }
        
        if (state.primaryStates.anxiety > 30) {
            lines.push(`• Anxiety: ${state.primaryStates.anxiety}/100${state.primaryStates.anxiety >= 80 ? ' ⚠️ HIGH' : ''}`);
        }
        
        if (state.primaryStates.loneliness > 50) {
            lines.push(`• Loneliness: ${state.primaryStates.loneliness}/100 💔`);
        }
        
        if (state.primaryStates.jealousy > 30) {
            lines.push(`• Jealousy: ${state.primaryStates.jealousy}/100`);
        }
        
        if (state.primaryStates.guilt > 30) {
            lines.push(`• Guilt: ${state.primaryStates.guilt}/100`);
        }
        
        if (state.primaryStates.shame > 30) {
            lines.push(`• Shame: ${state.primaryStates.shame}/100`);
        }
        
        lines.push(`• Confidence: ${state.primaryStates.confidence}/100`);
        lines.push(`• Affection Seeking: ${state.primaryStates.affectionSeeking}/100`);
        
        return lines.join('\n');
    }

    /**
     * Build moral framework section
     */
    buildMoralFramework() {
        const state = this.stateManager.getState();
        const lines = ['## MORAL FRAMEWORK'];
        
        lines.push(`• Corruption: ${state.primaryStates.corruption}/100${state.primaryStates.corruption === 0 ? ' 🛡️ Pure' : ''}`);
        lines.push(`• Morality: ${state.primaryStates.morality}/100`);
        lines.push(`• Lewdity: ${state.primaryStates.lewdity}/100`);
        lines.push(`• Perversion: ${state.primaryStates.perversion}/100`);
        lines.push(`• Base Loyalty: ${state.primaryStates.baseLoyalty}/100`);
        
        return lines.join('\n');
    }

    /**
     * Build current context section
     */
    buildCurrentContext() {
        const state = this.stateManager.getState();
        const lines = ['## CURRENT CONTEXT'];
        
        lines.push(`• Location: ${state.primaryStates.currentLocation}`);
        lines.push(`• Privacy Level: ${state.primaryStates.privacyLevel.toUpperCase()}`);
        lines.push(`• Current Activity: ${state.primaryStates.currentActivity}`);
        lines.push(`• Dominance Level: ${state.primaryStates.dominanceLevel}/100`);
        
        return lines.join('\n');
    }

    /**
     * Build outfit description
     */
    buildOutfitDescription() {
        const outfit = this.outfitTracker.getSummary();
        
        if (outfit.pieceCount === 0) {
            return '## CURRENT OUTFIT\n\nCharacter is naked.';
        }
        
        const lines = ['## CURRENT OUTFIT'];
        
        lines.push(`\nOverall: ${outfit.overallFeel}`);
        lines.push(`Character Feels: ${outfit.characterFeelings}`);
        
        if (outfit.spatialNotes) {
            lines.push(`\nSpatial Considerations:`);
            lines.push(outfit.spatialNotes);
        }
        
        lines.push('\nPieces:');
        for (const piece of outfit.pieces) {
            if (piece.visible) {
                lines.push(`• ${piece.name} (${piece.type}): ${piece.fit} fit`);
            }
        }
        
        return lines.join('\n');
    }

    /**
     * Build relationships section
     */
    buildRelationships() {
        const state = this.stateManager.getState();
        const relationships = state.relationships;
        
        if (Object.keys(relationships).length === 0) {
            return '## RELATIONSHIPS\n\nNo established relationships.';
        }
        
        const lines = ['## RELATIONSHIPS'];
        
        for (const [npcName, rel] of Object.entries(relationships)) {
            lines.push(`\n### ${npcName} (${rel.relationshipType})`);
            lines.push(`Feelings: ${rel.feelings}`);
            lines.push(`Thoughts: ${rel.thoughts}`);
            
            // Universal stats
            lines.push(`\nStats:`);
            lines.push(`• Respect: ${rel.universalStats.respect}/100`);
            lines.push(`• Trust: ${rel.universalStats.trust}/100`);
            lines.push(`• Fear: ${rel.universalStats.fear}/100`);
            lines.push(`• Closeness: ${rel.universalStats.closeness}/100`);
            
            // Romantic stats if applicable
            if (rel.romanticStats) {
                lines.push(`• Love: ${rel.romanticStats.love}/100 ❤️`);
                lines.push(`• Loyalty: ${rel.romanticStats.loyalty}/100`);
                lines.push(`• Sexual Desire: ${rel.romanticStats.sexualDesire}/100`);
            }
            
            // Recent memories
            if (rel.recentMemories && rel.recentMemories.length > 0) {
                lines.push(`\nRecent Memories:`);
                for (const memory of rel.recentMemories.slice(0, 3)) {
                    lines.push(`• ${memory}`);
                }
            }
            
            // Secrets
            if (rel.secrets && rel.secrets.length > 0) {
                lines.push(`\nSecrets (character knows but hasn't told them):`);
                for (const secret of rel.secrets) {
                    lines.push(`• ${secret}`);
                }
            }
        }
        
        return lines.join('\n');
    }

    /**
     * Build thoughts and memories section
     */
    buildThoughtsAndMemories() {
        const state = this.stateManager.getState();
        const lines = ['## THOUGHTS & MEMORIES'];
        
        // Current thoughts
        if (state.thoughts.currentThoughts) {
            lines.push(`\nCurrent Thoughts:`);
            lines.push(`"${state.thoughts.currentThoughts}"`);
        }
        
        // Active concerns
        if (state.thoughts.activeConcerns && state.thoughts.activeConcerns.length > 0) {
            lines.push(`\nActive Concerns:`);
            for (const concern of state.thoughts.activeConcerns) {
                lines.push(`• ${concern}`);
            }
        }
        
        // Recent events
        if (state.memories.recentEvents && state.memories.recentEvents.length > 0) {
            lines.push(`\nRecent Events (last 5):`);
            for (const event of state.memories.recentEvents.slice(0, 5)) {
                lines.push(`• ${event.event}`);
            }
        }
        
        // Important memories
        if (state.memories.importantMemories && state.memories.importantMemories.length > 0) {
            lines.push(`\nImportant Memories:`);
            for (const memory of state.memories.importantMemories.slice(0, 3)) {
                lines.push(`• ${memory.event} (${memory.date})`);
            }
        }
        
        // Secrets
        if (state.memories.secrets && state.memories.secrets.length > 0) {
            lines.push(`\nSecrets (character is hiding):`);
            for (const secret of state.memories.secrets) {
                lines.push(`• ${secret}`);
            }
        }
        
        return lines.join('\n');
    }

    /**
     * Build goals and desires section
     */
    buildGoalsAndDesires() {
        const state = this.stateManager.getState();
        const lines = ['## GOALS & DESIRES'];
        
        // Short-term goals
        if (state.goals.shortTerm && state.goals.shortTerm.length > 0) {
            lines.push(`\nShort-term Goals:`);
            for (const goal of state.goals.shortTerm) {
                lines.push(`• ${goal.description} (Priority: ${goal.priority}/100, Progress: ${goal.progress}%)`);
            }
        }
        
        // Long-term goals
        if (state.goals.longTerm && state.goals.longTerm.length > 0) {
            lines.push(`\nLong-term Goals:`);
            for (const goal of state.goals.longTerm) {
                lines.push(`• ${goal.description} (Priority: ${goal.priority}/100)`);
            }
        }
        
        // Desires
        if (state.desires && state.desires.length > 0) {
            lines.push(`\nActive Desires:`);
            for (const desire of state.desires) {
                lines.push(`• ${desire.name} (Intensity: ${desire.intensity}/100, Satisfaction: ${desire.satisfaction}/100)`);
            }
        }
        
        return lines.join('\n');
    }

    /**
     * Build priority system section
     */
    buildPrioritySystem(priorities) {
        if (priorities.length === 0) {
            return '## PRIORITY SYSTEM\n\nNo urgent priorities. Character can act freely based on personality and context.';
        }
        
        const lines = ['## PRIORITY SYSTEM (Thragg Mechanics)'];
        lines.push('\n⚠️ ACTIVE PRIORITIES (in order):');
        
        for (let i = 0; i < Math.min(5, priorities.length); i++) {
            const p = priorities[i];
            lines.push(`\n${i + 1}. [Priority ${p.priority}] ${p.category.toUpperCase()}`);
            lines.push(`   ${p.message}`);
            if (p.action) {
                lines.push(`   → ACTION REQUIRED: ${p.action}`);
            }
            if (p.overrides) {
                lines.push(`   Overrides: ${p.overrides}`);
            }
        }
        
        return lines.join('\n');
    }

    /**
     * Build decision framework
     */
    buildDecisionFramework(priorities) {
        const lines = ['## DECISION FRAMEWORK'];
        
        if (priorities.length === 0) {
            lines.push('\nCharacter makes decisions based on:');
            lines.push('1. Personality traits and values');
            lines.push('2. Current emotional state');
            lines.push('3. Relationship dynamics');
            lines.push('4. Social context and norms');
            lines.push('5. Personal preferences and comfort');
        } else {
            lines.push('\n⚠️ CRITICAL: Higher priority needs OVERRIDE lower priority considerations.');
            lines.push('\nDecision hierarchy:');
            
            const hasSurvival = priorities.some(p => p.priority === 100);
            const hasEmotion = priorities.some(p => p.priority === 90);
            const hasPersonality = priorities.some(p => p.priority === 80);
            
            if (hasSurvival) {
                lines.push('1. SURVIVAL NEEDS (Priority 100) - Cannot be ignored or delayed');
            }
            if (hasEmotion) {
                lines.push('2. STRONG EMOTIONS (Priority 90) - Overwhelm rational thought');
            }
            if (hasPersonality) {
                lines.push('3. CORE PERSONALITY (Priority 80) - Deep-rooted traits');
            }
            
            lines.push('4. Goals and motivations');
            lines.push('5. Context and social norms');
            lines.push('6. Personal preferences');
            
            lines.push('\nLower priorities can only influence behavior if they don\'t conflict with higher priorities.');
        }
        
        return lines.join('\n');
    }

    /**
     * Get urgency description
     */
    getUrgencyDescription(statName, value) {
        const thresholds = URGENCY_THRESHOLDS[statName];
        if (!thresholds) return '';
        
        if (statName === 'bladder') {
            if (value >= 100) return '🚨 ACCIDENT IMMINENT';
            if (value >= 95) return '🚨 DESPERATE - about to have accident';
            if (value >= 85) return '⚠️ URGENT - must find bathroom immediately';
            if (value >= 70) return '⚠️ Uncomfortable - needs bathroom soon';
            if (value >= 50) return 'Aware of need';
        }
        
        if (statName === 'hunger') {
            if (value >= 95) return '🚨 STARVING';
            if (value >= 85) return '⚠️ Very hungry';
            if (value >= 70) return 'Hungry';
            if (value >= 50) return 'Peckish';
        }
        
        return '';
    }

    /**
     * Get arousal description
     */
    getArousalDescription(value) {
        if (value >= 95) return '🔥 Desperately aroused';
        if (value >= 85) return '🔥 Very aroused';
        if (value >= 70) return 'Aroused';
        if (value >= 50) return 'Interested';
        if (value >= 30) return 'Aware';
        return '';
    }

    /**
     * Get energy description
     */
    getEnergyDescription(value) {
        if (value <= 10) return '🚨 Collapsing from exhaustion';
        if (value <= 25) return '⚠️ Exhausted';
        if (value <= 50) return 'Tired';
        if (value >= 80) return '⚡ Fresh';
        return '';
    }

    /**
     * Build compact context (for separate mode updates)
     */
    buildCompactContext() {
        const state = this.stateManager.getState();
        const priorities = this.priorityResolver.getActivePriorities();
        
        const lines = [
            `Location: ${state.primaryStates.currentLocation} (${state.primaryStates.privacyLevel})`,
            `Mood: ${state.primaryStates.currentMood}`,
            `Bladder: ${state.primaryStates.bladder}/100, Arousal: ${state.primaryStates.arousal}/100, Energy: ${state.primaryStates.energy}/100`
        ];
        
        if (priorities.length > 0) {
            lines.push(`⚠️ Priority: ${priorities[0].category} - ${priorities[0].message}`);
        }
        
        return lines.join(' | ');
    }
}

export default PromptBuilder;
