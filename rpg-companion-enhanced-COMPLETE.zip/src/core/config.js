/**
 * RPG Companion Enhanced - Core Configuration
 * Version: 2.0.0
 * 
 * Basic configuration for extension identity
 */

export const extensionName = 'rpg-companion';
export const extensionFolderPath = 'third-party/rpg-companion';
export const extensionVersion = '2.0.0';
