/**
 * Core Configuration for Advanced RPG Companion
 * Contains all state definitions, constants, and default values
 */

export const extensionName = 'rpg-companion-advanced';
export const extensionFolderPath = `scripts/extensions/${extensionName}`;
export const extensionVersion = '2.0.0';

/**
 * PRIMARY STATE DEFINITIONS (38 Core States)
 */
export const PRIMARY_STATES = {
    // Physical States (10)
    PHYSICAL: {
        bladder: { min: 0, max: 100, default: 30, category: 'physical', priority: 100, label: 'Bladder' },
        arousal: { min: 0, max: 100, default: 10, category: 'physical', priority: 70, label: 'Arousal' },
        hunger: { min: 0, max: 100, default: 40, category: 'physical', priority: 95, label: 'Hunger' },
        energy: { min: 0, max: 100, default: 70, category: 'physical', priority: 90, label: 'Energy' },
        pain: { min: 0, max: 100, default: 0, category: 'physical', priority: 95, label: 'Pain' },
        cleanliness: { min: 0, max: 100, default: 85, category: 'physical', priority: 30, label: 'Cleanliness' },
        temperature: { min: 0, max: 100, default: 50, category: 'physical', priority: 70, label: 'Temperature' },
        health: { min: 0, max: 100, default: 95, category: 'physical', priority: 100, label: 'Health' },
        intoxication: { min: 0, max: 100, default: 0, category: 'physical', priority: 85, label: 'Intoxication' },
        cycleDay: { min: 1, max: 28, default: 1, category: 'physical', priority: 50, label: 'Cycle Day' }
    },
    
    // Emotional States (10)
    EMOTIONAL: {
        happiness: { min: 0, max: 100, default: 60, category: 'emotional', priority: 60, label: 'Happiness' },
        stress: { min: 0, max: 100, default: 30, category: 'emotional', priority: 85, label: 'Stress' },
        anxiety: { min: 0, max: 100, default: 20, category: 'emotional', priority: 80, label: 'Anxiety' },
        loneliness: { min: 0, max: 100, default: 40, category: 'emotional', priority: 65, label: 'Loneliness' },
        confidence: { min: 0, max: 100, default: 60, category: 'emotional', priority: 55, label: 'Confidence' },
        jealousy: { min: 0, max: 100, default: 0, category: 'emotional', priority: 75, label: 'Jealousy' },
        guilt: { min: 0, max: 100, default: 0, category: 'emotional', priority: 70, label: 'Guilt' },
        shame: { min: 0, max: 100, default: 0, category: 'emotional', priority: 70, label: 'Shame' },
        affectionSeeking: { min: 0, max: 100, default: 50, category: 'emotional', priority: 60, label: 'Affection Seeking' },
        currentMood: { type: 'text', default: 'Content', category: 'emotional', priority: 50, label: 'Current Mood' }
    },
    
    // Moral States (5)
    MORAL: {
        corruption: { min: 0, max: 100, default: 0, category: 'moral', priority: 80, label: 'Corruption' },
        morality: { min: 0, max: 100, default: 80, category: 'moral', priority: 80, label: 'Morality' },
        lewdity: { min: 0, max: 100, default: 10, category: 'moral', priority: 70, label: 'Lewdity' },
        perversion: { min: 0, max: 100, default: 5, category: 'moral', priority: 70, label: 'Perversion' },
        baseLoyalty: { min: 0, max: 100, default: 90, category: 'moral', priority: 85, label: 'Base Loyalty' }
    },
    
    // Contextual States (5)
    CONTEXTUAL: {
        currentLocation: { type: 'text', default: 'Home', category: 'contextual', priority: 40, label: 'Location' },
        privacyLevel: { type: 'enum', values: ['private', 'semi-private', 'public'], default: 'private', category: 'contextual', priority: 50, label: 'Privacy Level' },
        currentActivity: { type: 'text', default: 'Idle', category: 'contextual', priority: 30, label: 'Current Activity' },
        speechMode: { type: 'text', default: 'Normal', category: 'contextual', priority: 20, label: 'Speech Mode' },
        dominanceLevel: { min: 0, max: 100, default: 50, category: 'contextual', priority: 60, label: 'Dominance' }
    },
    
    // Body Language States (7)
    BODY_LANGUAGE: {
        earPosition: { type: 'text', default: 'Normal', category: 'body', priority: 20, label: 'Ear Position' },
        tailMovement: { type: 'text', default: 'Calm', category: 'body', priority: 20, label: 'Tail Movement' },
        purring: { type: 'boolean', default: false, category: 'body', priority: 20, label: 'Purring' },
        nippleState: { type: 'text', default: 'Relaxed', category: 'body', priority: 30, label: 'Nipple State' },
        scent: { type: 'text', default: 'Normal', category: 'body', priority: 20, label: 'Scent' },
        breathingPattern: { type: 'text', default: 'Normal', category: 'body', priority: 40, label: 'Breathing' },
        facialExpression: { type: 'text', default: 'Neutral', category: 'body', priority: 30, label: 'Expression' }
    },
    
    // Special States (1)
    SPECIAL: {
        auraIntensity: { min: 0, max: 100, default: 0, category: 'special', priority: 40, label: 'Aura Intensity' }
    }
};

/**
 * RELATIONSHIP STATS DEFINITIONS
 */
export const RELATIONSHIP_STATS = {
    // Universal (all relationships)
    UNIVERSAL: {
        respect: { min: 0, max: 100, default: 50, label: 'Respect' },
        fear: { min: 0, max: 100, default: 0, label: 'Fear' },
        obedience: { min: 0, max: 100, default: 30, label: 'Obedience' },
        dominance: { min: 0, max: 100, default: 50, label: 'Dominance' },
        trust: { min: 0, max: 100, default: 50, label: 'Trust' },
        closeness: { min: 0, max: 100, default: 40, label: 'Closeness' }
    },
    
    // Romantic only
    ROMANTIC: {
        love: { min: 0, max: 100, default: 50, label: 'Love' },
        loyalty: { min: 0, max: 100, default: 80, label: 'Loyalty' },
        attraction: { min: 0, max: 100, default: 60, label: 'Attraction' },
        sexualDesire: { min: 0, max: 100, default: 50, label: 'Sexual Desire' }
    }
};

/**
 * RELATIONSHIP TYPES
 */
export const RELATIONSHIP_TYPES = [
    'Stranger',
    'Acquaintance',
    'Friend',
    'Best Friend',
    'Family - Parent',
    'Family - Sibling',
    'Family - Child',
    'Lover',
    'Secret Lover',
    'Husband',
    'Wife',
    'Ex-Lover',
    'Enemy',
    'Rival',
    'Mentor',
    'Student',
    'Master',
    'Servant',
    'Obsessed (One-sided)',
    'Custom'
];

/**
 * OUTFIT REVEALING LEVELS
 */
export const REVEALING_LEVELS = ['none', 'minimal', 'low', 'medium', 'high', 'very high', 'extreme'];

/**
 * OUTFIT EMPHASIS LEVELS
 */
export const EMPHASIS_LEVELS = ['none', 'slight', 'moderate', 'high', 'very high'];

/**
 * OUTFIT FIT TYPES
 */
export const FIT_TYPES = ['very loose', 'loose', 'comfortable', 'snug', 'tight', 'very tight', 'skin-tight'];

/**
 * SLOW-BURN RATE OPTIONS
 */
export const GROWTH_RATES = ['very slow', 'slow', 'medium', 'fast', 'very fast'];
export const DECAY_RATES = ['never', 'very slow', 'slow', 'medium', 'fast'];

/**
 * PRIORITY LEVELS (Thragg System)
 */
export const PRIORITY_LEVELS = {
    SURVIVAL: 100,      // Bladder 85+, Hunger 85+, Pain 80+, Health critical
    STRONG_EMOTION: 90, // Stress 85+, Anxiety 80+, Fear 80+, Arousal 85+ (context)
    CORE_PERSONALITY: 80, // Loyalty 90+, Morality 85+, Core beliefs
    GOALS: 70,          // Active goals, strong desires
    CONTEXT: 50,        // Social norms, location appropriateness
    PREFERENCES: 30,    // Likes, dislikes, comfort
    MINOR: 10           // Aesthetic choices, idle thoughts
};

/**
 * URGENCY THRESHOLDS
 */
export const URGENCY_THRESHOLDS = {
    bladder: {
        aware: 50,
        uncomfortable: 70,
        urgent: 85,
        desperate: 95,
        accident: 100
    },
    hunger: {
        peckish: 50,
        hungry: 70,
        very_hungry: 85,
        starving: 95
    },
    energy: {
        fresh: 80,
        tired: 50,
        exhausted: 25,
        collapsing: 10
    },
    arousal: {
        aware: 30,
        interested: 50,
        aroused: 70,
        very_aroused: 85,
        desperate: 95
    }
};

/**
 * DEFAULT SLOW-BURN SETTINGS
 */
export const DEFAULT_SLOW_BURN = {
    globalPreset: 'realistic',
    
    perStatSettings: {
        // Love - very slow growth
        love: {
            growthRate: 'very slow',
            decayRate: 'never',
            maxChangePerEvent: 5,
            maxChangePerDay: 20,
            requirements: { minTrust: 50, minCloseness: 60 },
            canSpikeUp: false,
            canSpikeDown: true,
            spikeMultiplier: 2
        },
        
        // Trust - slow growth
        trust: {
            growthRate: 'slow',
            decayRate: 'very slow',
            maxChangePerEvent: 10,
            maxChangePerDay: 30,
            canSpikeUp: false,
            canSpikeDown: true,
            spikeMultiplier: 3
        },
        
        // Fear - fast growth, slow decay
        fear: {
            growthRate: 'fast',
            decayRate: 'slow',
            maxChangePerEvent: 30,
            maxChangePerDay: 60,
            canSpikeUp: true,
            canSpikeDown: false,
            spikeMultiplier: 3
        },
        
        // Respect - medium growth
        respect: {
            growthRate: 'medium',
            decayRate: 'slow',
            maxChangePerEvent: 15,
            maxChangePerDay: 40,
            canSpikeUp: false,
            canSpikeDown: true,
            spikeMultiplier: 2
        },
        
        // Arousal - fast growth and decay
        arousal: {
            growthRate: 'medium',
            decayRate: 'fast',
            maxChangePerEvent: 20,
            maxChangePerDay: 80,
            canSpikeUp: true,
            canSpikeDown: true,
            spikeMultiplier: 2,
            baselineReversion: true,
            baseline: 10,
            baselineRate: 5
        },
        
        // Corruption - very slow, never decays
        corruption: {
            growthRate: 'very slow',
            decayRate: 'never',
            maxChangePerEvent: 3,
            maxChangePerDay: 10,
            requirements: { repeatedActions: true },
            canSpikeUp: false,
            canSpikeDown: false
        },
        
        // Bladder - time-based automatic
        bladder: {
            growthRate: 'automatic',
            hourlyIncrease: 5,
            drinkMultiplier: 3,
            decayRate: 'instant',
            overridesPriority: true
        },
        
        // Hunger - time-based automatic
        hunger: {
            growthRate: 'automatic',
            hourlyIncrease: 8,
            decayRate: 'instant'
        },
        
        // Energy - time-based automatic
        energy: {
            growthRate: 'automatic',
            hourlyDecrease: 6,
            sleepRestoration: 100,
            decayRate: 'instant'
        }
    },
    
    globalRules: {
        preventUnrealisticJumps: true,
        requireLogicalProgression: true,
        timeBasedDecay: true,
        relationshipMomentum: true
    }
};

/**
 * TIME-BASED DECAY RATES (per hour)
 */
export const TIME_DECAY_RATES = {
    bladder: +5,        // increases over time
    hunger: +8,         // increases over time
    energy: -6,         // decreases over time (awake)
    arousal: -5,        // decays to baseline
    cleanliness: -0.5,  // slowly decreases
    stress: -2,         // slowly decreases (natural recovery)
    anxiety: -3         // decays faster than stress
};

/**
 * DEFAULT EXTENSION SETTINGS
 */
export const DEFAULT_SETTINGS = {
    enabled: true,
    autoUpdate: true,
    updateDepth: 4,
    generationMode: 'separate',
    useSeparatePreset: false,
    
    // Display options
    showUserStats: true,
    showInfoBox: true,
    showThoughts: true,
    showOutfit: true,
    showRelationships: true,
    showGoals: true,
    showMemories: true,
    showPriorityAlerts: true,
    
    // Panel settings
    panelPosition: 'right',
    theme: 'default',
    
    // Advanced features
    enableSlowBurn: true,
    enablePrioritySystem: true,
    enableTimeDecay: true,
    enableAutoInference: true,
    
    // Customization
    customStates: {},
    slowBurnSettings: DEFAULT_SLOW_BURN
};

/**
 * BIOLOGY CYCLE PHASES
 */
export const CYCLE_PHASES = {
    menstruation: { days: [1, 2, 3, 4, 5], label: 'Menstruation', emoji: '🔴' },
    follicular: { days: [6, 7, 8, 9, 10, 11, 12, 13], label: 'Follicular', emoji: '🌱' },
    ovulation: { days: [14, 15], label: 'Ovulation', emoji: '💫' },
    luteal: { days: [16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28], label: 'Luteal', emoji: '🌙' }
};

/**
 * Get cycle phase from day number
 */
export function getCyclePhase(day) {
    for (const [phase, data] of Object.entries(CYCLE_PHASES)) {
        if (data.days.includes(day)) {
            return { phase, ...data };
        }
    }
    return { phase: 'unknown', label: 'Unknown', emoji: '❓' };
}

/**
 * VALIDATION CONSTANTS
 */
export const VALIDATION = {
    MAX_MEMORY_EVENTS: 50,
    MAX_IMPORTANT_MEMORIES: 20,
    MAX_SECRETS: 10,
    MAX_GOALS: 20,
    MAX_OUTFIT_PIECES: 15,
    MAX_NPCS: 50,
    MAX_CUSTOM_STATES: 30,
    
    // String lengths
    MAX_THOUGHT_LENGTH: 500,
    MAX_FEELING_LENGTH: 500,
    MAX_NARRATIVE_LENGTH: 2000,
    MAX_MEMORY_LENGTH: 300
};

/**
 * STORAGE KEYS
 */
export const STORAGE_KEYS = {
    SETTINGS: 'rpg_advanced_settings',
    CURRENT_STATE: 'rpg_advanced_current_state',
    CHAT_PREFIX: 'rpg_advanced_chat_',
    SWIPE_PREFIX: 'rpg_advanced_swipe_'
};

export default {
    extensionName,
    extensionFolderPath,
    extensionVersion,
    PRIMARY_STATES,
    RELATIONSHIP_STATS,
    RELATIONSHIP_TYPES,
    REVEALING_LEVELS,
    EMPHASIS_LEVELS,
    FIT_TYPES,
    GROWTH_RATES,
    DECAY_RATES,
    PRIORITY_LEVELS,
    URGENCY_THRESHOLDS,
    DEFAULT_SLOW_BURN,
    TIME_DECAY_RATES,
    DEFAULT_SETTINGS,
    CYCLE_PHASES,
    getCyclePhase,
    VALIDATION,
    STORAGE_KEYS
};
