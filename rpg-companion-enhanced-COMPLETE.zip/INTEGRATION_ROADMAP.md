# 🎮 RPG COMPANION ENHANCED - INTEGRATION ROADMAP

## 📋 INTEGRATION STRATEGY

### **GOAL:**
Enhance the existing vanilla RPG Companion with advanced features while maintaining **100% backward compatibility**.

---

## 🏗️ ARCHITECTURE

### **Layered Enhancement Approach:**

```
┌─────────────────────────────────────────────────────┐
│         VANILLA RPG COMPANION (Base Layer)          │
│  ✅ User Stats, Info Box, Thoughts, Inventory       │
│  ✅ Together/Separate mode, Themes, Mobile support  │
│  ✅ Swipe support, Live editing, Tracker config     │
└─────────────────────────────────────────────────────┘
                        ▲
                        │ Extends
                        │
┌─────────────────────────────────────────────────────┐
│       ENHANCED LAYER (Advanced Features)            │
│  🆕 Advanced State Manager (60-70+ fields)          │
│  🆕 Slow-Burn Validator (realistic progression)     │
│  🆕 Priority Resolver (Thragg system)               │
│  🆕 Outfit Tracker (detailed spatial reasoning)     │
│  🆕 Enhanced Prompt Builder (rich context)          │
└─────────────────────────────────────────────────────┘
```

---

## 📦 FILE STRUCTURE

```
rpg-companion-enhanced/
├── manifest.json                    ✅ Enhanced v2.0
├── index.js                         🔄 Enhanced entry point
├── style.css                        🔄 Enhanced styles
├── template.html                    🔄 Enhanced UI
├── settings.html                    🔄 Enhanced settings
├── LICENSE                          ✅ Keep original
├── README.md                        🔄 Enhanced docs
│
└── src/
    ├── core/
    │   ├── config.js                ✅ Vanilla config
    │   ├── advancedConfig.js        🆕 Advanced constants
    │   ├── state.js                 ✅ Vanilla state
    │   ├── advancedState.js         🆕 Advanced StateManager
    │   ├── persistence.js           🔄 Enhanced with advanced persistence
    │   └── events.js                🔄 Enhanced with advanced events
    │
    ├── systems/
    │   ├── states/
    │   │   ├── StateManager.js      🆕 Advanced state manager
    │   │   ├── PriorityResolver.js  🆕 Thragg priority system
    │   │   ├── OutfitTracker.js     🆕 Detailed outfit tracking
    │   │   └── BiologySystem.js     🆕 Time-based biology
    │   │
    │   ├── relationships/
    │   │   ├── SlowBurnValidator.js 🆕 Realistic progression
    │   │   └── RelationshipManager.js 🆕 NPC relationship manager
    │   │
    │   ├── generation/
    │   │   ├── promptBuilder.js     ✅ Vanilla prompt builder
    │   │   ├── enhancedPromptBuilder.js 🆕 Rich context builder
    │   │   ├── parser.js            ✅ Vanilla parser
    │   │   ├── enhancedParser.js    🆕 Advanced parser
    │   │   ├── apiClient.js         ✅ Vanilla API client
    │   │   └── injector.js          🔄 Enhanced with advanced context
    │   │
    │   ├── rendering/
    │   │   ├── userStats.js         🔄 Enhanced with advanced stats
    │   │   ├── infoBox.js           ✅ Keep vanilla
    │   │   ├── thoughts.js          ✅ Keep vanilla
    │   │   ├── inventory.js         ✅ Keep vanilla
    │   │   ├── quests.js            ✅ Keep vanilla
    │   │   ├── advancedPanel.js     🆕 Advanced features panel
    │   │   ├── outfitDisplay.js     🆕 Outfit visualization
    │   │   └── relationshipGraph.js 🆕 Relationship visualization
    │   │
    │   ├── ui/
    │   │   ├── theme.js             ✅ Keep vanilla
    │   │   ├── modals.js            🔄 Add advanced modals
    │   │   ├── trackerEditor.js     🔄 Enhanced with advanced trackers
    │   │   ├── layout.js            🔄 Enhanced layout
    │   │   ├── mobile.js            ✅ Keep vanilla
    │   │   └── desktop.js           ✅ Keep vanilla
    │   │
    │   ├── integration/
    │   │   └── sillytavern.js       🔄 Enhanced with advanced hooks
    │   │
    │   ├── features/
    │   │   ├── plotProgression.js   ✅ Keep vanilla
    │   │   ├── classicStats.js      ✅ Keep vanilla
    │   │   ├── htmlCleaning.js      ✅ Keep vanilla
    │   │   ├── memoryRecollection.js ✅ Keep vanilla
    │   │   ├── lorebookLimiter.js   ✅ Keep vanilla
    │   │   ├── advancedStates.js    🆕 Advanced state features
    │   │   └── priorities.js        🆕 Priority alerts & warnings
    │   │
    │   └── interaction/
    │       ├── inventoryActions.js  ✅ Keep vanilla
    │       ├── stateActions.js      🆕 Advanced state editing
    │       └── outfitActions.js     🆕 Outfit editing
    │
    └── utils/
        ├── avatars.js               ✅ Keep vanilla
        ├── validation.js            🆕 Advanced validation
        ├── compression.js           🆕 LZ-string compression
        └── helpers.js               🆕 General utilities
```

**Legend:**
- ✅ Keep vanilla (no changes)
- 🔄 Enhanced (modify existing)
- 🆕 New file (add advanced feature)

---

## 🎯 INTEGRATION POINTS

### **1. State Management**

**Vanilla:**
```javascript
// Vanilla tracks basic stats
extensionSettings = {
    userStats: { health: 80, mana: 60 },
    infoBox: { location: "Tavern" },
    thoughts: "Feeling good"
}
```

**Enhanced:**
```javascript
// Enhanced adds advanced state manager
import StateManager from './src/systems/states/StateManager.js';
const advancedState = new StateManager();

// Still compatible with vanilla
// But adds 60-70+ fields when enabled
```

---

### **2. Prompt Building**

**Vanilla:**
```javascript
// Vanilla builds basic prompts
function generateRPGPromptText() {
    return `Stats: Health ${stats.health}/100\nLocation: ${location}`;
}
```

**Enhanced:**
```javascript
// Enhanced adds rich context builder
import PromptBuilder from './src/systems/generation/enhancedPromptBuilder.js';
const promptBuilder = new PromptBuilder(stateManager, priorityResolver, outfitTracker);

// Returns full context if advanced mode enabled
// Falls back to vanilla if disabled
function generateRPGPromptText() {
    if (extensionSettings.advancedMode) {
        return promptBuilder.buildFullContext();
    }
    return vanillaPromptBuilder(); // Original function
}
```

---

### **3. Settings UI**

**Vanilla Settings:**
- Enable/disable extension
- Theme selection
- Panel position
- Generation mode

**Enhanced Settings:**
```javascript
// Add new settings tab: "Advanced Features"
settings: {
    // Vanilla settings (unchanged)
    enabled: true,
    theme: 'cyberpunk',
    panelPosition: 'right',
    generationMode: 'separate',
    
    // NEW: Advanced settings
    advancedMode: false,  // Enable/disable advanced features
    advancedFeatures: {
        detailedOutfits: true,
        slowBurnMechanics: true,
        prioritySystem: true,
        relationshipTracking: true,
        advancedBiology: true
    },
    slowBurnSettings: { ...DEFAULT_SLOW_BURN }
}
```

---

### **4. UI Integration**

**Vanilla UI:**
```
┌─────────────────────────┐
│ User Stats              │
│ Info Box                │
│ Present Characters      │
│ Inventory               │
│ Quests                  │
└─────────────────────────┘
```

**Enhanced UI:**
```
┌─────────────────────────┐
│ User Stats              │  ← Vanilla
│ Info Box                │  ← Vanilla
│ Present Characters      │  ← Vanilla
│ Inventory               │  ← Vanilla
│ Quests                  │  ← Vanilla
├─────────────────────────┤
│ 🆕 ADVANCED FEATURES    │  ← New collapsible section
│  ├─ Detailed Outfit     │
│  ├─ Priorities (Thragg) │
│  ├─ Relationships       │
│  └─ Advanced States     │
└─────────────────────────┘
```

---

## 🔧 IMPLEMENTATION PHASES

### **Phase 1: Foundation** ✅ (DONE)
- ✅ Advanced config
- ✅ StateManager
- ✅ SlowBurnValidator
- ✅ PriorityResolver
- ✅ OutfitTracker
- ✅ Enhanced PromptBuilder

### **Phase 2: Integration** (CURRENT)
- 🔄 Copy vanilla files
- 🔄 Add advanced modules to src/
- 🔄 Create integration hooks
- 🔄 Update index.js entry point
- 🔄 Add advanced settings

### **Phase 3: UI Enhancement** (NEXT)
- ⏳ Enhanced template.html
- ⏳ Enhanced style.css
- ⏳ Advanced panel component
- ⏳ Outfit editor
- ⏳ Relationship graph

### **Phase 4: Persistence** (AFTER UI)
- ⏳ IndexedDB for advanced states
- ⏳ Compression
- ⏳ Per-swipe advanced data
- ⏳ Migration from vanilla

### **Phase 5: Testing & Polish** (FINAL)
- ⏳ Test vanilla compatibility
- ⏳ Test advanced features
- ⏳ Performance optimization
- ⏳ Documentation
- ⏳ User guide

---

## 💡 KEY DESIGN PRINCIPLES

### **1. Backward Compatibility**
- All vanilla features work unchanged
- Advanced features are **opt-in**
- Can disable advanced mode entirely
- Falls back gracefully

### **2. Progressive Enhancement**
- Start with vanilla
- Enable advanced features one by one
- User controls everything
- No forced changes

### **3. Modular Design**
- Each advanced feature is independent
- Can enable outfit tracking without slow-burn
- Can enable priorities without relationships
- Mix and match

### **4. Clean Separation**
- Vanilla code untouched where possible
- Advanced code in separate files
- Clear integration points
- Easy to maintain

---

## 🎮 USER EXPERIENCE

### **Default (Vanilla Mode):**
```
User enables extension
→ Works exactly like vanilla RPG Companion
→ No advanced features visible
→ Perfect for existing users
```

### **Opt-in (Advanced Mode):**
```
User enables "Advanced Mode" in settings
→ New "Advanced Features" section appears
→ User enables specific features:
  ☑ Detailed Outfit Tracking
  ☑ Slow-Burn Mechanics
  ☑ Priority System (Thragg)
  ☑ Relationship Tracking
→ Extension uses enhanced systems
→ Richer context, more realistic behavior
```

### **Customization:**
```
User can:
- Enable/disable each advanced feature
- Customize slow-burn rates
- Add custom states
- Configure priorities
- Design outfit templates
→ Total control
```

---

## 📝 NEXT STEPS

1. ✅ Create enhanced manifest
2. ⏳ Copy vanilla files to proper locations
3. ⏳ Add advanced systems to src/
4. ⏳ Create integration layer
5. ⏳ Update index.js with advanced hooks
6. ⏳ Enhance settings UI
7. ⏳ Add advanced panel to template
8. ⏳ Test integration
9. ⏳ Document everything
10. ⏳ Package for distribution

---

**STATUS: Phase 2 (Integration) IN PROGRESS**
