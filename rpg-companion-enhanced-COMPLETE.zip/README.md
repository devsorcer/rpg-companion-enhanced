# 🎮 RPG Companion Enhanced v2.0

**The most comprehensive character simulation system for SillyTavern**

Enhanced version of Marysia's RPG Companion with advanced state tracking (60-70+ fields), detailed outfit system, relationship management, slow-burn mechanics, and Thragg priority system.

---

## ⭐ WHAT'S ENHANCED

### **🆕 Advanced State Tracking (60-70+ Fields)**
- **38 Primary States**: Physical, Emotional, Moral, Contextual, Body Language, Special
- **Biology System**: Menstrual cycles, pregnancy, timestamps
- **Memory System**: Recent events, important memories, secrets, traumas
- **Thoughts System**: Current thoughts, per-NPC thoughts, active concerns
- **Beliefs & Desires**: Dynamic belief/desire tracking with intensity
- **Goals System**: Short-term, long-term, and secret goals

### **🆕 Detailed Outfit Tracking**
- Track every piece of clothing separately
- Revealing levels (7 levels: none → extreme)
- Body part emphasis tracking
- **Spatial reasoning**: "Dress so short that sitting exposes underwear"
- Character feelings about outfit
- Auto-generated narrative descriptions

### **🆕 Slow-Burn Mechanics**
- Realistic stat progression (no 0→100 jumps)
- Per-stat growth/decay rates
- Requirements (Love needs Trust 50+)
- Logical progression validation
- Relationship momentum (established relationships harder to change)
- Fully customizable per stat

### **🆕 Thragg Priority System**
- **6 Priority Levels**: Survival (100) → Preferences (10)
- Bladder 85+ overrides EVERYTHING
- Context-aware decisions
- Realistic human behavior
- Infinite behavioral variations

### **🆕 Rich Context Generation**
- Natural human-readable language for AI
- Priority alerts and warnings
- Decision framework
- Context-driven (AI interprets, not parses)
- Creates infinite variations from same scenario

---

## ✨ ALL VANILLA FEATURES INCLUDED

✅ **User Stats Tracker** - Fully customizable with progress bars  
✅ **Info Box Dashboard** - Date, weather, time, location, events  
✅ **Present Characters Panel** - Track multiple characters with thoughts  
✅ **Floating Thought Bubbles** - Next to character avatars  
✅ **Classic RPG Stats** - STR, DEX, CON, INT, WIS, CHA  
✅ **Advanced Inventory System** - Multi-location storage  
✅ **Plot Progression** - Randomized or natural events  
✅ **Multiple Themes** - Cyberpunk, Fantasy, Minimal, Dark, Light, Custom  
✅ **Live Editing** - Edit all tracker fields directly  
✅ **Per-Swipe Data Storage** - Each swipe preserves data  
✅ **Mobile Support** - Responsive design  
✅ **Together/Separate Modes** - Choose generation method  

---

## 🚀 QUICK START

### **Installation:**

1. Open SillyTavern
2. Go to Extensions tab
3. Click "Install extension"
4. Enter: `https://github.com/[your-repo]/rpg-companion-enhanced`
5. Click Install

### **Basic Use (Vanilla Mode):**

1. Enable extension in Extensions tab
2. Works exactly like vanilla RPG Companion
3. All original features available
4. No advanced features enabled by default

### **Enable Advanced Features:**

1. Open RPG Companion panel
2. Click "Settings" → "Advanced Features" tab
3. Toggle "Enable Advanced Mode"
4. Select which features to enable:
   - ☑ Detailed Outfit Tracking
   - ☑ Slow-Burn Mechanics
   - ☑ Priority System (Thragg)
   - ☑ Relationship Tracking
   - ☑ Advanced Biology
5. Customize settings as desired
6. Start chatting!

---

## 🎯 HOW IT WORKS

### **Context-Driven Approach**

**Traditional (Parser-Based) - What We DON'T Do:**
```javascript
if (bladder > 90) {
    return "*squirms* 'I need bathroom'"; // Same every time
}
```

**Our Approach (Context-Driven):**
```
AI receives rich context:
"Bladder: 91/100 - URGENT - must find bathroom immediately
Location: Public market with 20 strangers
Personality: Modest, hates discussing bathroom needs
Priority: SURVIVAL (100) - overrides social embarrassment"

AI naturally interprets and responds differently every time based on full context!
```

### **Infinite Variations**

**Same Scenario, Different States = Different Behavior**

**Scenario:** Stranger flirts with character

**State 1:** Loyalty 100 + Morality 85 + Public  
→ Result: Cold rejection, walks away

**State 2:** Loyalty 100 + Arousal 70 + Husband watching  
→ Result: Teases stranger to make husband jealous

**State 3:** Bladder 96 + ANY STATE  
→ Result: "Bathroom emergency!" *runs away*  
→ **SURVIVAL OVERRIDES EVERYTHING**

---

## 📊 WHAT'S BEING TRACKED

### **When Advanced Mode Enabled:**

**Primary States (38):**
- Physical (10): bladder, arousal, hunger, energy, pain, cleanliness, temperature, health, intoxication, cycleDay
- Emotional (10): happiness, stress, anxiety, loneliness, confidence, jealousy, guilt, shame, affectionSeeking, currentMood
- Moral (5): corruption, morality, lewdity, perversion, baseLoyalty
- Contextual (5): location, privacyLevel, activity, speechMode, dominanceLevel
- Body Language (7): earPosition, tailMovement, purring, nippleState, scent, breathing, expression
- Special (1): auraIntensity

**Additional Systems:**
- Biology: cycle day/phase, pregnancy, timestamps
- Outfit: detailed pieces with revealing/emphasis/spatial notes
- Memories: recent events (50 max), important (20 max), secrets (10 max)
- Thoughts: current, per-NPC, active concerns
- Beliefs: array with strength/category
- Desires: intensity, satisfaction, priority
- Goals: short-term, long-term, secret
- Relationships: per-NPC with full stats

**Total: 60-70+ tracked fields!**

---

## ⚙️ ADVANCED SETTINGS

### **Slow-Burn Configuration**

Customize how each stat changes:

```javascript
love: {
  growthRate: 'very slow',    // How fast it grows
  decayRate: 'never',          // How fast it decays
  maxChangePerEvent: 5,        // Max change per event
  requirements: {
    minTrust: 50              // Needs Trust 50+ to grow
  },
  canSpikeUp: false,          // Can't jump suddenly
  canSpikeDown: true          // Can drop suddenly (betrayal)
}
```

**Growth Rates:** very slow, slow, medium, fast, very fast  
**Decay Rates:** never, very slow, slow, medium, fast

### **Priority System**

**6 Priority Levels:**
1. **Survival (100)**: Bladder 85+, Hunger 85+, Energy <15
2. **Strong Emotion (90)**: Stress 85+, Anxiety 80+
3. **Core Personality (80)**: Loyalty 90+, Morality 85+
4. **Goals (70)**: High-priority active goals
5. **Context (50)**: Public/private, social norms
6. **Preferences (30)**: Comfort, cleanliness

Higher priorities OVERRIDE lower ones!

---

## 🎨 EXAMPLE: DETAILED OUTFIT TRACKING

```javascript
{
  type: 'dress',
  name: 'White ribbed sweater dress',
  fit: 'very tight',
  material: 'ribbed knit',
  color: 'white',
  
  revealing: {
    cleavage: 'high',      // 7 levels: none → extreme
    legs: 'high',           // Shows to mid-thigh
    midriff: 'none',
    back: 'none',
    sides: 'none',
    transparency: 'none'
  },
  
  emphasis: {
    breasts: 'very high',  // Ribbed fabric clings
    waist: 'high',
    hips: 'high',
    butt: 'medium'
  },
  
  spatialNotes: "Dress so short that sitting would expose underwear. Deep neckline shows bra when bending forward.",
  
  characterFeelings: "Feels sexy but vulnerable, aware of how exposed she is"
}
```

---

## 👥 RELATIONSHIP TRACKING

**Per-NPC Tracking:**
```javascript
Dev (Husband):
  - Feelings: "Deeply in love, obsessed, devoted"
  - Thoughts: "I wonder when he'll come home..."
  - Universal Stats: respect, fear, obedience, dominance, trust, closeness
  - Romantic Stats: love, loyalty, attraction, sexualDesire
  - Recent Memories: [3 recent interactions]
  - Secrets: ["Planning to tell him about transformation"]
  - Custom slow-burn rates per stat
```

---

## 🛠️ DEVELOPMENT

### **Architecture:**

```
Vanilla RPG Companion (Base)
    ↓ Extends
Enhanced Layer (Advanced Features)
    ↓ Provides
Rich Context → AI → Realistic Behavior
```

### **Core Systems:**

1. **StateManager** - Tracks all 60-70+ fields
2. **SlowBurnValidator** - Ensures realistic progression
3. **PriorityResolver** - Implements Thragg system
4. **OutfitTracker** - Detailed outfit & spatial reasoning
5. **PromptBuilder** - Generates rich natural language context

All systems are modular and optional!

---

## 📝 COMPATIBILITY

### **Backward Compatible:**
- All vanilla features work unchanged
- Advanced features are **opt-in**
- Can disable advanced mode entirely
- Existing users see no difference unless they enable it

### **Requirements:**
- SillyTavern 1.11.0 or higher
- Works with all AI backends (OpenAI, Claude, KoboldAI, etc.)
- Compatible with all vanilla RPG Companion features

---

## 🎉 WHY IT'S PERFECT

✅ **Complete State Tracking** - 60-70+ fields  
✅ **Realistic Slow-Burn** - No unrealistic jumps  
✅ **Thragg Priority System** - Survival > Emotion > Personality  
✅ **Detailed Outfit System** - Spatial reasoning, feelings  
✅ **Rich Context Generation** - Natural language for AI  
✅ **Infinite Variations** - Different states = different behavior  
✅ **100% Backward Compatible** - Works with vanilla  
✅ **Fully Customizable** - Control everything  
✅ **Production Ready** - Polished, bug-free code  

---

## 📄 LICENSE

GNU Affero General Public License v3.0

Original RPG Companion by Marysia  
Enhanced by Dev + Claude

---

## 🙏 CREDITS

**Original RPG Companion:**
- Extension Development: Marysia with GitHub Copilot
- Immersive HTML concept: u/melted_walrus
- Info Box prompt inspiration: MidnightSleeper
- CSS help: Quack
- Mobile/inventory: Paperboy
- CSS scaling: IDeathByte

**Enhanced Version:**
- Advanced Systems Design: Dev + Claude
- Integration: Dev + Claude
- Based on Marysia's excellent foundation

---

## 💖 SUPPORT

- [Original Creator's Discord](https://discord.com/invite/KdAkTg94ME)
- [Original Creator's Ko-fi](https://ko-fi.com/marinara_spaghetti)

---

Made with ❤️ by Marysia, Dev, and Claude

**Experience the most realistic character simulation in SillyTavern!**
