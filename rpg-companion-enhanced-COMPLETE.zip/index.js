import { getContext, renderExtensionTemplateAsync, extension_settings as st_extension_settings } from '../../../extensions.js';
import { eventSource, event_types, substituteParams, chat, generateRaw, saveSettingsDebounced, chat_metadata, saveChatDebounced, user_avatar, getThumbnailUrl, characters, this_chid, extension_prompt_types, extension_prompt_roles, setExtensionPrompt, reloadCurrentChat, Generate, getRequestHeaders } from '../../../../script.js';
import { selected_group, getGroupMembers } from '../../../group-chats.js';
import { power_user } from '../../../power-user.js';

// Core modules
import { extensionName, extensionFolderPath } from './src/core/config.js';

// Advanced systems (Enhanced)
import StateManager from './src/systems/states/StateManager.js';
import SlowBurnValidator from './src/systems/relationships/SlowBurnValidator.js';
import PriorityResolver from './src/systems/states/PriorityResolver.js';
import OutfitTracker from './src/systems/states/OutfitTracker.js';
import PromptBuilder from './src/systems/generation/enhancedPromptBuilder.js';

// Advanced state management
let advancedStateManager = null;
let slowBurnValidator = null;
let priorityResolver = null;
let outfitTracker = null;
let enhancedPromptBuilder = null;

// Extension settings with advanced features
const defaultExtensionSettings = {
    enabled: true,
    autoUpdate: true,
    updateDepth: 4,
    memoryMessagesToProcess: 15,
    generationMode: 'separate',
    useSeparatePreset: false,
    showUserStats: true,
    showInfoBox: true,
    showCharacterThoughts: true,
    showInventory: true,
    showThoughtsInChat: false,
    alwaysShowThoughtBubble: false,
    enableHtmlPrompt: false,
    customHtmlPrompt: '',
    skipInjectionsForGuided: 'none',
    panelPosition: 'right',
    theme: 'cyberpunk',
    customColors: {
        primary: '#e94560',
        secondary: '#0f3460',
        accent: '#16213e',
        text: '#ffffff',
        background: '#1a1a2e'
    },
    useCustomColors: false,
    enableAnimations: true,
    
    // 🆕 ADVANCED FEATURES
    advancedMode: false,
    advancedFeatures: {
        detailedOutfits: true,
        slowBurnMechanics: true,
        prioritySystem: true,
        relationshipTracking: true,
        advancedBiology: true
    },
    
    // Tracker configurations
    userStatsConfig: {
        stats: ['Health', 'Mana', 'Stamina'],
        statusFields: ['mood', 'status', 'condition'],
        skillFields: ['Skill 1', 'Skill 2'],
        enableRpgAttributes: true
    },
    infoBoxConfig: {
        widgets: {
            date: true,
            weather: true,
            temperature: true,
            time: true,
            location: true,
            recentEvents: true
        },
        temperatureUnit: 'celsius'
    },
    presentCharactersConfig: {
        customFields: ['appearance', 'action', 'demeanor'],
        enableRelationshipStatus: true,
        enableCharacterStats: true,
        thoughtBubbleLabel: 'Internal Thoughts'
    }
};

let extensionSettings = { ...defaultExtensionSettings };
let lastGeneratedData = null;
let committedTrackerData = null;
let lastActionWasSwipe = false;
let isGenerating = false;
let isPlotProgression = false;
let pendingDiceRoll = null;

// Cached jQuery elements
let $panelContainer = null;
let $userStatsContainer = null;
let $infoBoxContainer = null;
let $thoughtsContainer = null;
let $inventoryContainer = null;
let $questsContainer = null;
let $advancedPanel = null;

/**
 * Initialize advanced systems when advanced mode is enabled
 */
function initializeAdvancedSystems() {
    if (!extensionSettings.advancedMode) {
        console.log('[RPG Companion Enhanced] Advanced mode disabled - using vanilla only');
        return;
    }
    
    console.log('[RPG Companion Enhanced] Initializing advanced systems...');
    
    try {
        // Initialize core advanced systems
        advancedStateManager = new StateManager();
        slowBurnValidator = new SlowBurnValidator();
        priorityResolver = new PriorityResolver(advancedStateManager);
        outfitTracker = new OutfitTracker(advancedStateManager);
        enhancedPromptBuilder = new PromptBuilder(advancedStateManager, priorityResolver, outfitTracker);
        
        console.log('[RPG Companion Enhanced] ✅ Advanced systems initialized successfully');
        console.log('[RPG Companion Enhanced] - StateManager: tracking 60-70+ fields');
        console.log('[RPG Companion Enhanced] - SlowBurnValidator: realistic progression enabled');
        console.log('[RPG Companion Enhanced] - PriorityResolver: Thragg system active');
        console.log('[RPG Companion Enhanced] - OutfitTracker: detailed outfit tracking enabled');
        console.log('[RPG Companion Enhanced] - PromptBuilder: rich context generation ready');
        
        // Load advanced state from chat metadata if it exists
        loadAdvancedState();
        
        // Update UI to show advanced features
        updateAdvancedUI();
        
    } catch (error) {
        console.error('[RPG Companion Enhanced] ❌ Failed to initialize advanced systems:', error);
        toastr.error('Advanced features failed to initialize. Check console for details.', 'RPG Companion Enhanced');
        
        // Disable advanced mode on failure
        extensionSettings.advancedMode = false;
        saveSettings();
    }
}

/**
 * Load advanced state from chat metadata
 */
function loadAdvancedState() {
    if (!advancedStateManager || !chat_metadata) return;
    
    try {
        const savedState = chat_metadata.rpg_companion_advanced_state;
        if (savedState) {
            advancedStateManager.import(savedState);
            console.log('[RPG Companion Enhanced] ✅ Advanced state loaded from chat metadata');
        }
    } catch (error) {
        console.error('[RPG Companion Enhanced] Failed to load advanced state:', error);
    }
}

/**
 * Save advanced state to chat metadata
 */
function saveAdvancedState() {
    if (!advancedStateManager || !chat_metadata) return;
    
    try {
        chat_metadata.rpg_companion_advanced_state = advancedStateManager.export();
        saveChatDebounced();
        console.log('[RPG Companion Enhanced] ✅ Advanced state saved to chat metadata');
    } catch (error) {
        console.error('[RPG Companion Enhanced] Failed to save advanced state:', error);
    }
}

/**
 * Update UI to show/hide advanced features
 */
function updateAdvancedUI() {
    if (!$advancedPanel) return;
    
    if (extensionSettings.advancedMode) {
        $advancedPanel.show();
        renderAdvancedPanel();
    } else {
        $advancedPanel.hide();
    }
}

/**
 * Render advanced features panel
 */
function renderAdvancedPanel() {
    if (!$advancedPanel || !advancedStateManager) return;
    
    try {
        // Get current state summary
        const summary = advancedStateManager.getSummary();
        const priorities = priorityResolver.getActivePriorities();
        const outfitSummary = outfitTracker.getSummary();
        
        // Build HTML for advanced panel
        let html = `
            <div class="rpg-section-header">
                <h4><i class="fa-solid fa-brain"></i> Advanced State</h4>
            </div>
            
            <!-- Priority Alerts -->
            ${priorities.length > 0 ? `
                <div class="rpg-priority-alerts">
                    <strong>🚨 Active Priorities:</strong>
                    ${priorities.slice(0, 3).map(p => `
                        <div class="rpg-priority-item priority-${p.priority >= 90 ? 'critical' : p.priority >= 70 ? 'high' : 'medium'}">
                            <span class="priority-badge">${p.priority}</span>
                            <span class="priority-text">${p.description}</span>
                        </div>
                    `).join('')}
                </div>
            ` : ''}
            
            <!-- Physical States -->
            <div class="rpg-advanced-section">
                <strong>Physical States:</strong>
                <div class="rpg-state-grid">
                    ${summary.physical.map(s => `
                        <div class="rpg-state-item">
                            <span class="state-label">${s.label}:</span>
                            <span class="state-value">${s.value}/100 ${s.urgency ? `⚠️ ${s.urgency}` : ''}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
            
            <!-- Emotional States -->
            <div class="rpg-advanced-section">
                <strong>Emotional States:</strong>
                <div class="rpg-state-grid">
                    ${summary.emotional.filter(s => s.value > 30).map(s => `
                        <div class="rpg-state-item">
                            <span class="state-label">${s.label}:</span>
                            <span class="state-value">${s.value}/100</span>
                        </div>
                    `).join('')}
                </div>
            </div>
            
            <!-- Outfit -->
            ${outfitSummary.pieces.length > 0 ? `
                <div class="rpg-advanced-section">
                    <strong>Current Outfit:</strong>
                    <div class="rpg-outfit-summary">
                        <div class="outfit-feel">${outfitSummary.overallFeel || 'Casual'}</div>
                        <div class="outfit-pieces">
                            ${outfitSummary.pieces.map(p => `
                                <span class="outfit-piece">${p.name}</span>
                            `).join('')}
                        </div>
                    </div>
                </div>
            ` : ''}
            
            <!-- Quick Actions -->
            <div class="rpg-advanced-actions">
                <button id="rpg-edit-advanced-state" class="rpg-btn-secondary">
                    <i class="fa-solid fa-edit"></i> Edit State
                </button>
                <button id="rpg-view-advanced-context" class="rpg-btn-secondary">
                    <i class="fa-solid fa-eye"></i> View Full Context
                </button>
            </div>
        `;
        
        $advancedPanel.html(html);
        
        // Set up event listeners for advanced panel buttons
        $('#rpg-edit-advanced-state').on('click', () => openAdvancedStateEditor());
        $('#rpg-view-advanced-context').on('click', () => showFullContext());
        
    } catch (error) {
        console.error('[RPG Companion Enhanced] Failed to render advanced panel:', error);
        $advancedPanel.html(`<div class="rpg-error">Failed to render advanced state. Check console.</div>`);
    }
}

/**
 * Open advanced state editor modal
 */
function openAdvancedStateEditor() {
    if (!advancedStateManager) return;
    
    // Create modal HTML
    const modalHtml = `
        <div id="rpg-advanced-state-modal" class="rpg-modal">
            <div class="rpg-modal-content rpg-modal-large">
                <div class="rpg-modal-header">
                    <h3><i class="fa-solid fa-edit"></i> Advanced State Editor</h3>
                    <button class="rpg-modal-close">&times;</button>
                </div>
                <div class="rpg-modal-body">
                    <div class="rpg-tabs">
                        <button class="rpg-tab-btn active" data-tab="physical">Physical</button>
                        <button class="rpg-tab-btn" data-tab="emotional">Emotional</button>
                        <button class="rpg-tab-btn" data-tab="outfit">Outfit</button>
                        <button class="rpg-tab-btn" data-tab="relationships">Relationships</button>
                        <button class="rpg-tab-btn" data-tab="memories">Memories</button>
                    </div>
                    <div class="rpg-tab-content">
                        <div id="rpg-tab-physical" class="rpg-tab-pane active">
                            ${renderPhysicalStatesEditor()}
                        </div>
                        <div id="rpg-tab-emotional" class="rpg-tab-pane">
                            ${renderEmotionalStatesEditor()}
                        </div>
                        <div id="rpg-tab-outfit" class="rpg-tab-pane">
                            ${renderOutfitEditor()}
                        </div>
                        <div id="rpg-tab-relationships" class="rpg-tab-pane">
                            ${renderRelationshipsEditor()}
                        </div>
                        <div id="rpg-tab-memories" class="rpg-tab-pane">
                            ${renderMemoriesEditor()}
                        </div>
                    </div>
                </div>
                <div class="rpg-modal-footer">
                    <button id="rpg-save-advanced-state" class="rpg-btn-primary">Save Changes</button>
                    <button class="rpg-btn-secondary rpg-modal-close">Cancel</button>
                </div>
            </div>
        </div>
    `;
    
    // Add modal to body
    $('body').append(modalHtml);
    
    // Set up tab switching
    $('.rpg-tab-btn').on('click', function() {
        const tab = $(this).data('tab');
        $('.rpg-tab-btn').removeClass('active');
        $('.rpg-tab-pane').removeClass('active');
        $(this).addClass('active');
        $(`#rpg-tab-${tab}`).addClass('active');
    });
    
    // Set up close buttons
    $('.rpg-modal-close').on('click', () => {
        $('#rpg-advanced-state-modal').remove();
    });
    
    // Set up save button
    $('#rpg-save-advanced-state').on('click', () => {
        saveAdvancedStateFromEditor();
        $('#rpg-advanced-state-modal').remove();
        renderAdvancedPanel();
        saveAdvancedState();
        toastr.success('Advanced state saved successfully!');
    });
}

/**
 * Render physical states editor
 */
function renderPhysicalStatesEditor() {
    const state = advancedStateManager.state;
    const physicalStats = ['bladder', 'arousal', 'hunger', 'energy', 'pain', 'cleanliness'];
    
    return `
        <div class="rpg-editor-grid">
            ${physicalStats.map(stat => `
                <div class="rpg-editor-field">
                    <label>${stat.charAt(0).toUpperCase() + stat.slice(1)}:</label>
                    <input type="range" min="0" max="100" value="${state.primaryStates[stat] || 0}" 
                           data-state="${stat}" class="rpg-state-slider">
                    <span class="rpg-state-value">${state.primaryStates[stat] || 0}</span>
                </div>
            `).join('')}
        </div>
        <script>
            $('.rpg-state-slider').on('input', function() {
                const value = $(this).val();
                $(this).next('.rpg-state-value').text(value);
            });
        </script>
    `;
}

/**
 * Render emotional states editor
 */
function renderEmotionalStatesEditor() {
    const state = advancedStateManager.state;
    const emotionalStats = ['happiness', 'stress', 'anxiety', 'loneliness', 'confidence'];
    
    return `
        <div class="rpg-editor-grid">
            ${emotionalStats.map(stat => `
                <div class="rpg-editor-field">
                    <label>${stat.charAt(0).toUpperCase() + stat.slice(1)}:</label>
                    <input type="range" min="0" max="100" value="${state.primaryStates[stat] || 50}" 
                           data-state="${stat}" class="rpg-state-slider">
                    <span class="rpg-state-value">${state.primaryStates[stat] || 50}</span>
                </div>
            `).join('')}
        </div>
        <script>
            $('.rpg-state-slider').on('input', function() {
                const value = $(this).val();
                $(this).next('.rpg-state-value').text(value);
            });
        </script>
    `;
}

/**
 * Render outfit editor
 */
function renderOutfitEditor() {
    return `
        <div class="rpg-outfit-editor">
            <button id="rpg-add-outfit-piece" class="rpg-btn-primary">
                <i class="fa-solid fa-plus"></i> Add Outfit Piece
            </button>
            <div id="rpg-outfit-pieces-list">
                <!-- Will be populated dynamically -->
            </div>
        </div>
    `;
}

/**
 * Render relationships editor
 */
function renderRelationshipsEditor() {
    const relationships = advancedStateManager.state.relationships;
    
    return `
        <div class="rpg-relationships-editor">
            <button id="rpg-add-relationship" class="rpg-btn-primary">
                <i class="fa-solid fa-plus"></i> Add Relationship
            </button>
            <div id="rpg-relationships-list">
                ${Object.keys(relationships).map(npcName => `
                    <div class="rpg-relationship-item">
                        <h5>${npcName}</h5>
                        <div class="rpg-relationship-stats">
                            <div class="stat-item">
                                <label>Trust:</label>
                                <input type="range" min="0" max="100" value="${relationships[npcName].universalStats.trust || 50}">
                            </div>
                            <div class="stat-item">
                                <label>Respect:</label>
                                <input type="range" min="0" max="100" value="${relationships[npcName].universalStats.respect || 50}">
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

/**
 * Render memories editor
 */
function renderMemoriesEditor() {
    const memories = advancedStateManager.state.memories;
    
    return `
        <div class="rpg-memories-editor">
            <h5>Recent Events:</h5>
            <textarea id="rpg-recent-events" rows="4" placeholder="Add recent events (one per line)...">${memories.recentEvents.map(e => e.event).join('\n')}</textarea>
            
            <h5>Important Memories:</h5>
            <textarea id="rpg-important-memories" rows="4" placeholder="Add important memories (one per line)...">${memories.importantMemories.map(m => m.memory).join('\n')}</textarea>
            
            <h5>Secrets:</h5>
            <textarea id="rpg-secrets" rows="4" placeholder="Add secrets (one per line)...">${memories.secrets.map(s => s.secret).join('\n')}</textarea>
        </div>
    `;
}

/**
 * Save advanced state from editor
 */
function saveAdvancedStateFromEditor() {
    // Save physical states
    $('.rpg-state-slider').each(function() {
        const statName = $(this).data('state');
        const value = parseInt($(this).val());
        advancedStateManager.updatePrimaryState(statName, value);
    });
    
    // Save memories
    const recentEvents = $('#rpg-recent-events').val().split('\n').filter(e => e.trim());
    const importantMemories = $('#rpg-important-memories').val().split('\n').filter(m => m.trim());
    const secrets = $('#rpg-secrets').val().split('\n').filter(s => s.trim());
    
    // Clear and re-add memories
    advancedStateManager.state.memories.recentEvents = recentEvents.map(event => ({ event, timestamp: Date.now() }));
    advancedStateManager.state.memories.importantMemories = importantMemories.map(memory => ({ memory, timestamp: Date.now() }));
    advancedStateManager.state.memories.secrets = secrets.map(secret => ({ secret, revealedTo: [] }));
}

/**
 * Show full context in modal
 */
function showFullContext() {
    if (!enhancedPromptBuilder) return;
    
    const fullContext = enhancedPromptBuilder.buildFullContext();
    
    const modalHtml = `
        <div id="rpg-context-modal" class="rpg-modal">
            <div class="rpg-modal-content rpg-modal-large">
                <div class="rpg-modal-header">
                    <h3><i class="fa-solid fa-eye"></i> Full AI Context</h3>
                    <button class="rpg-modal-close">&times;</button>
                </div>
                <div class="rpg-modal-body">
                    <pre class="rpg-context-display">${fullContext}</pre>
                    <button id="rpg-copy-context" class="rpg-btn-primary">
                        <i class="fa-solid fa-copy"></i> Copy to Clipboard
                    </button>
                </div>
                <div class="rpg-modal-footer">
                    <button class="rpg-btn-secondary rpg-modal-close">Close</button>
                </div>
            </div>
        </div>
    `;
    
    $('body').append(modalHtml);
    
    $('.rpg-modal-close').on('click', () => {
        $('#rpg-context-modal').remove();
    });
    
    $('#rpg-copy-context').on('click', () => {
        navigator.clipboard.writeText(fullContext);
        toastr.success('Context copied to clipboard!');
    });
}

/**
 * Load settings from storage
 */
function loadSettings() {
    const context = getContext();
    const savedSettings = context.extensionSettings?.[extensionName];
    
    if (savedSettings) {
        extensionSettings = { ...defaultExtensionSettings, ...savedSettings };
        console.log('[RPG Companion Enhanced] Settings loaded:', extensionSettings);
    }
    
    // Initialize advanced systems if advanced mode is enabled
    if (extensionSettings.advancedMode) {
        initializeAdvancedSystems();
    }
}

/**
 * Save settings to storage
 */
function saveSettings() {
    const context = getContext();
    if (!context.extensionSettings) {
        context.extensionSettings = {};
    }
    context.extensionSettings[extensionName] = extensionSettings;
    saveSettingsDebounced();
}

/**
 * Add extension settings to Extensions tab
 */
function addExtensionSettings() {
    const settingsHtml = `
        <div class="inline-drawer">
            <div class="inline-drawer-toggle inline-drawer-header">
                <b><i class="fa-solid fa-dice-d20"></i> RPG Companion Enhanced</b>
                <div class="inline-drawer-icon fa-solid fa-circle-chevron-down down"></div>
            </div>
            <div class="inline-drawer-content">
                <label class="checkbox_label" for="rpg-extension-enabled">
                    <input type="checkbox" id="rpg-extension-enabled" />
                    <span>Enable RPG Companion</span>
                </label>
                <small class="notes">Toggle to enable/disable the RPG Companion extension.</small>

                <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid var(--SmartThemeBorderColor);">
                    <label class="checkbox_label" for="rpg-advanced-mode-enabled">
                        <input type="checkbox" id="rpg-advanced-mode-enabled" />
                        <span>🆕 Enable Advanced Mode</span>
                    </label>
                    <small class="notes">
                        Enables advanced features: 60-70+ state tracking, detailed outfits, slow-burn mechanics, priority system (Thragg), and relationship tracking.
                    </small>
                </div>

                <div style="margin-top: 10px; display: flex; gap: 10px;">
                    <a href="https://discord.com/invite/KdAkTg94ME" target="_blank" class="menu_button" style="flex: 1; text-align: center; text-decoration: none;">
                        <i class="fa-brands fa-discord"></i> Discord
                    </a>
                    <a href="https://ko-fi.com/marinara_spaghetti" target="_blank" class="menu_button" style="flex: 1; text-align: center; text-decoration: none;">
                        <i class="fa-solid fa-heart"></i> Support Creator
                    </a>
                </div>
            </div>
        </div>
    `;

    $('#extensions_settings2').append(settingsHtml);

    // Set up enable/disable toggle
    $('#rpg-extension-enabled').prop('checked', extensionSettings.enabled).on('change', async function() {
        extensionSettings.enabled = $(this).prop('checked');
        saveSettings();

        if (extensionSettings.enabled) {
            await initUI();
        } else {
            $('#rpg-companion-panel').remove();
            $('#rpg-mobile-toggle').remove();
        }
    });

    // Set up advanced mode toggle
    $('#rpg-advanced-mode-enabled').prop('checked', extensionSettings.advancedMode).on('change', function() {
        const wasEnabled = extensionSettings.advancedMode;
        extensionSettings.advancedMode = $(this).prop('checked');
        saveSettings();

        if (extensionSettings.advancedMode && !wasEnabled) {
            initializeAdvancedSystems();
            toastr.success('Advanced mode enabled! New features available in panel.', 'RPG Companion Enhanced');
        } else if (!extensionSettings.advancedMode && wasEnabled) {
            // Disable advanced systems
            advancedStateManager = null;
            slowBurnValidator = null;
            priorityResolver = null;
            outfitTracker = null;
            enhancedPromptBuilder = null;
            updateAdvancedUI();
            toastr.info('Advanced mode disabled. Using vanilla features only.', 'RPG Companion Enhanced');
        }
    });
}

/**
 * Initialize UI
 */
async function initUI() {
    if (!extensionSettings.enabled) return;

    // Load template
    const templateHtml = await renderExtensionTemplateAsync(extensionName, 'template');
    $('body').append(templateHtml);

    // Cache UI elements
    $panelContainer = $('#rpg-companion-panel');
    $userStatsContainer = $('#rpg-user-stats');
    $infoBoxContainer = $('#rpg-info-box');
    $thoughtsContainer = $('#rpg-thoughts');
    $inventoryContainer = $('#rpg-inventory');
    $questsContainer = $('#rpg-quests');
    $advancedPanel = $('#rpg-advanced-panel');

    // Set up event listeners
    setupEventListeners();

    // Initialize advanced UI if advanced mode is enabled
    if (extensionSettings.advancedMode) {
        updateAdvancedUI();
    }

    console.log('[RPG Companion Enhanced] ✅ UI initialized');
}

/**
 * Set up event listeners
 */
function setupEventListeners() {
    // Advanced mode toggle in settings panel
    $('#rpg-toggle-advanced-mode').on('change', function() {
        extensionSettings.advancedMode = $(this).prop('checked');
        saveSettings();

        if (extensionSettings.advancedMode) {
            initializeAdvancedSystems();
        } else {
            updateAdvancedUI();
        }
    });
}

/**
 * Main initialization
 */
jQuery(async () => {
    try {
        console.log('[RPG Companion Enhanced] 🎮 Initializing...');

        // Load settings
        loadSettings();

        // Add extension settings
        addExtensionSettings();

        // Initialize UI
        await initUI();

        // Register event listeners
        eventSource.on(event_types.MESSAGE_SENT, () => {
            if (extensionSettings.advancedMode) {
                saveAdvancedState();
            }
        });

        eventSource.on(event_types.MESSAGE_RECEIVED, () => {
            if (extensionSettings.advancedMode) {
                renderAdvancedPanel();
            }
        });

        console.log('[RPG Companion Enhanced] ✅ Extension loaded successfully');
        if (extensionSettings.advancedMode) {
            console.log('[RPG Companion Enhanced] 🆕 Advanced mode active - Enhanced features enabled');
        }

    } catch (error) {
        console.error('[RPG Companion Enhanced] ❌ Initialization failed:', error);
        toastr.error('RPG Companion Enhanced failed to initialize. Check console.', 'Error');
    }
});
